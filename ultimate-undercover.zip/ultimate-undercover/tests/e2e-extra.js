/* Extra browser scenarios: Mr. White correct guess, tie + re-vote, 20 players, quick-vote mode, timers.
 * Run: node tests/e2e-extra.js */
'use strict';
process.env.PORT = process.env.PORT || '4190';
require('../server.js');
const { chromium } = require('playwright');
let failures = 0, checks = 0;
const ok = (c, m) => { checks++; if (!c) { failures++; console.error('  FAIL ' + m); } else console.log('  ok   ' + m); };

(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 412, height: 860 }, isMobile: true, hasTouch: true });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push(e.message));
  page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  await page.goto('http://localhost:' + process.env.PORT + '/');
  await page.waitForSelector('.brand');
  const screen = () => page.evaluate(() => UU.ui.name);
  const click = (n) => page.getByRole('button', { name: n }).first().click();

  async function setup(count, over) {
    await page.evaluate(([c, o]) => {
      const S = UU.ui.S; S.playerCount = c; Object.assign(S, o); UU.ui.saveSettings();
      UU.ui.setup.names = Array.from({ length: 20 }, (_, i) => 'P' + (i + 1));
      UU.ui.game = null; UU.ui.go('setup');
    }, [count, over]);
    await click(/Start game/);
    await page.waitForSelector('.pass-card');
  }
  async function reveal(count) {
    for (let i = 0; i < count; i++) {
      await page.getByRole('button', { name: /show my/ }).click();
      await page.getByRole('button', { name: /Hide/ }).click();
    }
  }
  async function voteRound(plan) { // plan: voterName -> targetName
    await click(/Go to voting|Start voting/);
    const n = await page.evaluate(() => UU.ui.game.vote.voters.length);
    for (let i = 0; i < n; i++) {
      const voter = await page.evaluate(() => UU.ui.game.players[UU.Engine.currentVoter(UU.ui.game)].name);
      await click(/— vote/);
      await page.locator('.vote-btn', { hasText: new RegExp('^' + plan(voter) + '$') }).click();
      await click(/Confirm vote/);
    }
  }

  console.log('Mr. White guesses correctly');
  await setup(5, { roleMode: 'manual', undercovers: 1, mrWhites: 1, mrWhiteEnabled: true, votingMode: 'secret', tieRule: 'revote', winRule: 'parity' });
  await reveal(5);
  const info = await page.evaluate(() => ({ mw: UU.ui.game.players.find((p) => p.role === 'mrwhite').name, word: UU.ui.game.words.civilian, other: UU.ui.game.players.find((p) => p.role !== 'mrwhite').name }));
  await voteRound((v) => (v === info.mw ? info.other : info.mw));
  await click(/Reveal their role/);
  await page.locator('.mystery').click();
  ok((await page.locator('.reveal-card.mrwhite').count()) === 1, 'eliminated Mr. White is revealed');
  await click(/last guess/);
  ok((await screen()) === 'guess', 'Mr. White gets a guess screen');
  ok(!(await page.evaluate(() => document.body.innerText)).includes(info.word), 'guess screen does not leak the Civilian word');
  await page.getByLabel('Your guess').fill(info.word.toLowerCase());
  await click(/Submit guess/);
  ok(/Correct/.test(await page.evaluate(() => document.body.innerText)), 'correct guess is recognised');
  await click(/See the results/);
  await page.waitForSelector('.banner');
  ok(/Mr\. White Wins/i.test(await page.evaluate(() => document.body.innerText)), 'Mr. White wins immediately');

  console.log('Tie -> re-vote');
  await setup(4, { roleMode: 'manual', undercovers: 1, mrWhites: 0, tieRule: 'revote' });
  await reveal(4);
  await voteRound((v) => ({ P1: 'P2', P2: 'P1', P3: 'P2', P4: 'P1' }[v]));
  ok(/tie/i.test(await page.evaluate(() => document.body.innerText)), 'tally announces the tie');
  await click(/re-vote/);
  const cands = await page.evaluate(() => UU.ui.game.vote.candidates.map((i) => UU.ui.game.players[i].name).sort());
  ok(cands.join() === 'P1,P2', 'only the tied players are on the re-vote ballot');
  await click(/— vote/);
  const opts = await page.evaluate(() => [...document.querySelectorAll('.vote-btn')].length);
  ok(opts >= 1 && opts <= 2, 'ballot shows only tied candidates (' + opts + ')');

  console.log('20 players');
  await setup(20, { roleMode: 'auto', mrWhiteEnabled: true });
  const counts = await page.evaluate(() => UU.Engine.counts(UU.ui.game));
  ok(counts.total === 20 && counts.civilians >= 1 && counts.impostors >= 1 && counts.impostors < counts.civilians, '20-player game has valid roles ' + JSON.stringify(counts));
  await reveal(20);
  ok((await screen()) === 'describe', 'all 20 players can be walked through role reveal');
  ok((await page.locator('.order .it').count()) === 20, 'speaking order lists 20 players');

  console.log('Quick vote mode');
  await setup(5, { roleMode: 'auto', votingMode: 'quick' });
  await reveal(5);
  await click(/Go to voting|Start voting/);
  ok((await page.locator('.vote-btn').count()) === 5, 'quick vote lists all players');
  await page.locator('.vote-btn').nth(2).click();
  await click(/Vote out/);
  await page.getByRole('button', { name: 'Confirm' }).click();
  ok((await screen()) === 'eliminate', 'quick vote eliminates the chosen player');

  console.log('Timer + random roles + hard difficulty');
  await setup(6, { roleMode: 'random', descSeconds: 15, votingMode: 'secret', difficulty: 'hard' });
  const hard = await page.evaluate(() => UU.ui.game.words.difficulty);
  ok(hard === 'hard', 'difficulty filter respected (got ' + hard + ')');
  await reveal(6);
  ok((await page.locator('.ring').count()) === 1, 'description timer ring is shown');
  ok(/Impostors: \?/.test(await page.evaluate(() => document.body.innerText)), 'random mode hides the impostor count');

  console.log('Category filter');
  await page.evaluate(() => { UU.ui.game = null; UU.ui.S.difficulty = 'all'; UU.ui.S.descSeconds = 0; UU.ui.S.categories = ['animals']; UU.ui.go('setup'); });
  await click(/Start game/);
  const cat = await page.evaluate(() => UU.ui.game.words.category);
  ok(cat === 'Animals', 'only the selected category is used (got ' + cat + ')');

  console.log('History exhaustion without recycling');
  await page.evaluate(() => {
    UU.ui.game = null; const S = UU.ui.S; S.categories = ['mathematics']; S.difficulty = 'hard'; S.allowRecycle = false;
    const f = { categories: S.categories, difficulty: S.difficulty };
    UU.WordBank.pool(f).forEach((i) => UU.history.add(UU.WordBank.ids[i])); UU.history.save();
    UU.ui.go('setup');
  });
  ok(await page.getByRole('button', { name: 'Start game' }).isDisabled(), 'start is blocked when the pool is exhausted and recycling is off');
  ok(/already been played/.test(await page.evaluate(() => document.body.innerText)), 'a clear reason is shown');
  await click(/Reset word history/);
  ok(await page.getByRole('button', { name: 'Start game' }).isEnabled(), 'resetting history unblocks the game');

  ok(errors.length === 0, 'no console or page errors' + (errors.length ? ': ' + errors.join(' | ') : ''));
  await browser.close();
  console.log('\n' + checks + ' checks, ' + failures + ' failed');
  process.exit(failures ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
