/* End-to-end test in a real (headless) browser: node tests/e2e.js
 * Drives the actual UI the way players would and checks secrets never leak.
 * Screenshots land in tests/screenshots/. */
'use strict';
const path = require('path');
const fs = require('fs');
process.env.PORT = process.env.PORT || '4173';
const server = require('../server.js');
const { chromium } = require('playwright');

const BASE = 'http://localhost:' + process.env.PORT + '/';
const SHOTS = path.join(__dirname, 'screenshots');
fs.mkdirSync(SHOTS, { recursive: true });
let failures = 0;
let checks = 0;
function ok(cond, msg) {
  checks++;
  if (!cond) { failures++; console.error('  FAIL ' + msg); } else console.log('  ok   ' + msg);
}

(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 412, height: 860 }, deviceScaleFactor: 2, hasTouch: true, isMobile: true });
  const page = await ctx.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
  page.on('console', (m) => { if (m.type() === 'error') errors.push('console: ' + m.text()); });

  const screen = () => page.evaluate(() => UU.ui.name);
  const shot = (name) => page.screenshot({ path: path.join(SHOTS, name + '.png') });
  const click = (name) => page.getByRole('button', { name }).first().click();
  const bodyText = () => page.evaluate(() => document.body.innerText);

  await page.goto(BASE);
  await page.waitForSelector('.brand');

  console.log('Home');
  ok((await screen()) === 'home', 'boots to home');
  ok(/word pairs/i.test(await bodyText()), 'home shows database statistics');
  const declared = await page.evaluate(() => UU_WORDS.count);
  const real = await page.evaluate(() => UU_WORDS.pairs.length);
  ok(declared === real && real >= 10000, 'displayed count (' + declared + ') equals real count (' + real + ')');
  ok((await bodyText()).includes(real.toLocaleString('en-US')), 'home displays the real pair count');
  await shot('01-home');

  console.log('Setup');
  await click(/^Play$/);
  ok((await screen()) === 'setup', 'Play opens setup');
  await shot('02-setup');
  const names = ['Asha', 'Ben', 'Chitra', 'Dev', 'Esha', 'Farid'];
  await page.getByRole('button', { name: 'increase' }).first().click(); // 5 -> 6 players
  for (let i = 0; i < 6; i++) await page.getByLabel('Name of player ' + (i + 1)).fill(names[i]);
  // duplicate-name validation
  await page.getByLabel('Name of player 2').fill('asha');
  ok(await page.getByRole('button', { name: 'Start game' }).isDisabled(), 'duplicate names block the start button');
  ok((await bodyText()).includes('different name'), 'duplicate names show an explanation');
  await page.getByLabel('Name of player 2').fill('Ben');
  ok(await page.getByRole('button', { name: 'Start game' }).isEnabled(), 'unique names enable the start button');
  await shot('03-setup-names');

  // manual roles validation
  await click(/^Manual$/);
  await page.evaluate(() => { UU.ui.S.undercovers = 3; UU.ui.S.mrWhites = 2; UU.ui.refresh(); });
  const clamped = await page.evaluate(() => UU.Engine.validateCounts(UU.ui.S.playerCount, UU.ui.S.undercovers, UU.ui.S.mrWhites, true).ok);
  ok(clamped, 'impossible manual role counts are clamped back to a valid distribution');
  await page.evaluate(() => { UU.ui.S.undercovers = 1; UU.ui.S.mrWhites = 1; UU.ui.refresh(); });
  ok(await page.getByRole('button', { name: 'Start game' }).isEnabled(), 'valid manual roles enable start');
  // no categories
  await page.getByRole('button', { name: 'None' }).click();
  ok(await page.getByRole('button', { name: 'Start game' }).isDisabled(), 'no categories blocks start');
  await page.getByRole('button', { name: 'All', exact: true }).click();

  console.log('Role distribution (privacy)');
  await click(/Start game/);
  await page.waitForSelector('.pass-card');
  ok((await screen()) === 'roles', 'game starts at role distribution');
  const secrets = await page.evaluate(() => UU.ui.game.players.map((p) => ({ name: p.name, role: p.role, word: p.word })));
  const allWords = await page.evaluate(() => [UU.ui.game.words.civilian, UU.ui.game.words.undercover]);
  const seenCards = [];
  await shot('04-pass');
  for (let i = 0; i < 6; i++) {
    // pass screen must not contain any word
    const passText = await bodyText();
    ok(passText.includes(names[i]), 'pass screen names ' + names[i]);
    ok(!allWords.some((w) => passText.includes(w)) || allWords.some((w) => names.includes(w)), 'no secret word visible on pass screen for ' + names[i]);
    await page.getByRole('button', { name: /show my/ }).click();
    await page.waitForSelector('.reveal-card');
    if (i === 0) await shot('05-reveal');
    const card = await page.evaluate(() => ({ word: document.querySelector('.reveal-card .word').innerText, rname: document.querySelector('.reveal-card .rname').innerText }));
    seenCards.push(card);
    // previous players' words must not be in DOM next to this card except their own
    const wordsInDom = await page.evaluate((ws) => ws.filter((w) => document.body.innerText.includes(w)), allWords);
    ok(wordsInDom.length === 1 || card.word === 'No word', 'only one word on screen while revealing ' + names[i]);
    await page.getByRole('button', { name: /Hide/ }).click();
  }
  ok((await screen()) === 'describe', 'after last player the description round starts');
  secrets.forEach((s, i) => {
    if (s.role === 'mrwhite') ok(seenCards[i].word === 'No word' && seenCards[i].rname.toLowerCase() === 'mr. white', s.name + ' (Mr. White) sees role but no word');
    else ok(seenCards[i].word === s.word, s.name + ' sees their own word');
  });
  ok(secrets.filter((s) => s.role === 'civilian').every((s) => s.word === allWords[0] || s.word === allWords[1]), 'civilians have a pair word');

  console.log('Description round');
  await shot('06-describe');
  const orderNames = await page.evaluate(() => [...document.querySelectorAll('.order .it b')].map((b) => b.innerText));
  ok(orderNames.length === 6, 'all 6 players listed in speaking order');
  const describeText = await bodyText();
  ok(!allWords.some((w) => describeText.includes(w)), 'no secret word shown on description screen');
  for (let i = 0; i < 6; i++) await page.getByRole('button', { name: /Next speaker|Finish round/ }).click();
  ok((await bodyText()).includes('Everyone has spoken'), 'all speakers done');
  // Check my word flow
  await click(/Check my word/);
  await page.getByRole('button', { name: 'Ben' }).click();
  await click(/Show my word/);
  await page.waitForSelector('.reveal-card');
  ok(true, 'peek shows a private card');
  await shot('07-peek');
  await click(/^Hide$/);
  ok((await page.locator('.reveal-card').count()) === 0, 'peek card closes');

  console.log('Voting (secret ballots)');
  await click(/Start voting/);
  await page.waitForSelector('.pass-card');
  ok((await screen()) === 'vote', 'voting screen');
  const firstVoter = await page.evaluate(() => UU.ui.game.players[UU.Engine.currentVoter(UU.ui.game)].name);
  await click(/— vote/);
  const options = await page.evaluate(() => [...document.querySelectorAll('.vote-btn')].map((b) => b.innerText));
  ok(!options.includes(firstVoter), 'voter cannot vote for themselves');
  ok(options.length === 5, 'five options for six players');
  await shot('08-ballot');
  // Everyone votes for "Asha" except Asha votes for Ben
  for (let i = 0; i < 6; i++) {
    const voter = await page.evaluate(() => UU.ui.game.players[UU.Engine.currentVoter(UU.ui.game)].name);
    if (i > 0) await click(/— vote/);
    await page.locator('.vote-btn', { hasText: voter === 'Asha' ? 'Ben' : 'Asha' }).click();
    await page.getByRole('button', { name: /Confirm vote/ }).click();
  }
  await page.waitForSelector('.tally');
  ok((await screen()) === 'tally', 'tally shows after all ballots');
  const tallyText = await bodyText();
  ok(/Asha[\s\S]*5 votes/.test(tallyText), 'tally shows 5 votes for Asha');
  await shot('09-tally');
  await click(/Reveal their role/);
  ok((await screen()) === 'eliminate', 'elimination screen');
  await shot('10-eliminate-hidden');
  await page.locator('.mystery').click();
  await page.waitForSelector('.reveal-card');
  await shot('11-eliminate-revealed');

  console.log('Finish the game through the UI');
  // keep playing: always vote out a civilian-or-whatever the group picks; Mr White guesses wrong; until result
  let guard = 0;
  while ((await screen()) !== 'result' && guard++ < 60) {
    const s = await screen();
    if (s === 'eliminate') {
      if (await page.locator('.mystery').count()) await page.locator('.mystery').click();
      await page.getByRole('button', { name: /Continue|last guess/ }).click();
    } else if (s === 'guess') {
      const g = await page.evaluate(() => UU.ui.game.phase);
      if (g === 'guess') { await page.getByLabel('Your guess').fill('wrong guess xyz'); await click(/Submit guess/); }
      else await page.getByRole('button', { name: /Continue|See the results/ }).click();
    } else if (s === 'describe') {
      await click(/Go to voting|Start voting/);
    } else if (s === 'vote') {
      const n = await page.evaluate(() => UU.ui.game.vote.voters.length - UU.ui.game.vote.index);
      for (let i = 0; i < n; i++) {
        await click(/— vote/);
        await page.locator('.vote-btn').first().click();
        await page.getByRole('button', { name: /Confirm vote/ }).click();
        if ((await screen()) !== 'vote') break;
      }
    } else if (s === 'tally') {
      await page.getByRole('button', { name: /Reveal their role|re-vote|Next round/ }).click();
    } else { await page.waitForTimeout(100); }
  }
  ok((await screen()) === 'result', 'game reaches the victory screen');
  await page.waitForSelector('.banner');
  await page.waitForTimeout(600);
  await shot('12-result');
  const resText = await bodyText();
  ok(/Wins!/.test(resText), 'victory screen names a winner');
  ok(resText.includes(allWords[0]) && resText.includes(allWords[1]), 'victory screen shows both original words');
  ok(resText.includes('Final roles'), 'victory screen lists final roles');

  console.log('Word history persistence');
  const usedBefore = await page.evaluate(() => JSON.parse(localStorage.getItem('uu.history.v1')).length);
  ok(usedBefore === 1, 'one pair recorded in history after one game (got ' + usedBefore + ')');
  await page.reload();
  await page.waitForSelector('.brand');
  ok((await bodyText()).includes('1 pairs played so far'), 'history survives a page refresh');
  const settingsKept = await page.evaluate(() => UU.ui.S.roleMode);
  ok(settingsKept === 'manual', 'settings survive a page refresh');

  console.log('Mid-game refresh + resume');
  await click(/^Play$/);
  await click(/Start game/);
  await page.waitForSelector('.pass-card');
  await page.getByRole('button', { name: /show my/ }).click();
  await page.waitForSelector('.reveal-card');
  await page.reload();
  await page.waitForSelector('.brand');
  ok((await bodyText()).includes('Resume game'), 'home offers to resume the unfinished game');
  await click(/Resume game/);
  await page.waitForSelector('.pass-card');
  ok((await page.locator('.reveal-card').count()) === 0, 'after refresh the secret is hidden again');
  ok((await page.evaluate(() => UU.ui.game.revealIndex)) === 0, 'resumes on the same player');
  const usedAfter = await page.evaluate(() => JSON.parse(localStorage.getItem('uu.history.v1')).length);
  ok(usedAfter === 2, 'second game recorded a second pair');

  console.log('Settings + history reset');
  await page.evaluate(() => { UU.ui.game = null; UU.ui.saveGame(); UU.ui.go('home'); });
  await click(/^Settings$/);
  await shot('13-settings');
  await page.getByRole('button', { name: /Reset word history/ }).click();
  await click(/^Reset$/);
  const usedReset = await page.evaluate(() => (JSON.parse(localStorage.getItem('uu.history.v1') || '[]')).length);
  ok(usedReset === 0, 'reset button clears history');
  await click(/^Light$/);
  ok((await page.evaluate(() => document.documentElement.dataset.theme)) === 'light', 'light theme applies');
  await shot('14-settings-light');
  await click(/^Dark$/);

  console.log('Offline');
  await page.evaluate(() => UU.ui.go('home'));
  await page.waitForTimeout(800);
  const swReady = await page.evaluate(async () => { const r = await navigator.serviceWorker.getRegistration(); return !!(r && (r.active || r.installing || r.waiting)); });
  ok(swReady, 'service worker registered');
  await page.evaluate(async () => { await navigator.serviceWorker.ready; });
  await page.waitForTimeout(500);
  await ctx.setOffline(true);
  await page.reload();
  await page.waitForSelector('.brand', { timeout: 8000 });
  ok(true, 'app loads while offline');
  ok(/word pairs/i.test(await bodyText()), 'offline app still has the word database');
  await ctx.setOffline(false);

  ok(errors.length === 0, 'no console or page errors' + (errors.length ? ': ' + errors.join(' | ') : ''));

  await browser.close();
  console.log('\n' + checks + ' checks, ' + failures + ' failed');
  process.exit(failures ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(1); });
