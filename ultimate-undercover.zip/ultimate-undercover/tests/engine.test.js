/* Automated tests for the engine and word bank. Run:  node tests/engine.test.js */
'use strict';
const assert = require('assert');
const same = (a, b, m) => assert.strictEqual(JSON.stringify(a), JSON.stringify(b), m);
const fs = require('fs');
const path = require('path');
const vm = require('vm');

/* load browser-style scripts into a shared sandbox */
const sandbox = { console };
sandbox.window = sandbox;
sandbox.globalThis = sandbox;
vm.createContext(sandbox);
for (const f of ['js/data/words.js', 'js/util.js', 'js/wordbank.js', 'js/engine.js']) {
  vm.runInContext(fs.readFileSync(path.join(__dirname, '..', f), 'utf8'), sandbox, { filename: f });
}
const UU = sandbox.UU;
const E = UU.Engine;
const seeded = UU.util.seededRng;

let passed = 0;
function test(name, fn) {
  try { fn(); passed++; console.log('  ok  ' + name); }
  catch (e) { console.error('FAIL  ' + name + '\n      ' + (e.stack || e)); process.exitCode = 1; }
}

const baseSettings = (o) => Object.assign({
  roleMode: 'auto', mrWhiteEnabled: true, undercovers: 1, mrWhites: 1,
  tieRule: 'revote', winRule: 'parity', votingMode: 'secret', descSeconds: 0, voteSeconds: 0,
}, o || {});
const names = (n) => Array.from({ length: n }, (_, i) => 'P' + (i + 1));
const pairOf = { a: 'Tiger', b: 'Lion', category: 'Animals', difficulty: 'easy', id: 'x' };
const newGame = (n, s, seed) => E.startGame({ names: names(n), settings: baseSettings(s), pair: pairOf, rng: seeded(seed || 1) });

console.log('Word database');
const WB = UU.WordBank;
test('declared count equals real count', () => {
  assert.strictEqual(UU.UU_WORDS ? 0 : 0, 0);
  const data = sandbox.UU_WORDS;
  assert.strictEqual(data.count, data.pairs.length);
  assert.strictEqual(WB.count, data.pairs.length);
});
test('at least 10,000 pairs', () => assert.ok(WB.count >= 10000, 'count=' + WB.count));
test('all 35 categories present and populated', () => {
  assert.strictEqual(WB.categories.length, 35);
  for (let i = 0; i < 35; i++) assert.ok(WB.pairs.some((p) => p[2] === i), 'empty category ' + i);
});
test('no duplicate or reversed pairs', () => {
  const seen = new Set();
  for (const [a, b] of WB.pairs) {
    const k = [UU.util.norm(a), UU.util.norm(b)].sort().join('|');
    assert.ok(!seen.has(k), 'duplicate ' + k);
    seen.add(k);
  }
});
test('no pair has identical or nested words', () => {
  for (const [a, b] of WB.pairs) {
    const x = ' ' + UU.util.norm(a) + ' ', y = ' ' + UU.util.norm(b) + ' ';
    assert.notStrictEqual(x, y);
    assert.ok(!x.includes(y) && !y.includes(x), a + '/' + b);
  }
});
test('all three difficulties populated', () => {
  for (const d of ['easy', 'medium', 'hard']) assert.ok(WB.pool({ difficulty: d }).length > 500, d);
});
test('pair ids are unique', () => assert.strictEqual(WB.idSet.size, WB.count));
test('category and difficulty filters are respected', () => {
  const pool = WB.pool({ categories: ['animals', 'music'], difficulty: 'medium' });
  assert.ok(pool.length > 0);
  for (const i of pool) {
    assert.ok(['Animals', 'Music'].includes(WB.categories[WB.pairs[i][2]].name));
    assert.strictEqual(WB.pairs[i][3], 1);
  }
});
test('picking never repeats until the pool is exhausted', () => {
  const storage = UU.createStorage({ setItem() {}, removeItem() {}, getItem: () => null });
  const hist = UU.createHistory(storage);
  const filter = { categories: ['mathematics'], difficulty: 'hard' }; // small pool
  const total = WB.pool(filter).length;
  assert.ok(total > 3 && total < 200, 'pool ' + total);
  const rng = seeded(7);
  const got = new Set();
  for (let i = 0; i < total; i++) {
    const r = WB.pick(filter, { allowRecycle: false }, hist, rng);
    assert.ok(!r.error);
    assert.ok(!got.has(r.pair.id), 'repeat before exhaustion');
    got.add(r.pair.id);
  }
  assert.strictEqual(WB.pick(filter, { allowRecycle: false }, hist, rng).error, 'exhausted');
  const again = WB.pick(filter, { allowRecycle: true }, hist, rng);
  assert.ok(again.recycled && again.pair);
  assert.strictEqual(WB.stats(filter, hist).used, 1);
});
test('history survives a "reload" through storage and can be reset', () => {
  const mem = {};
  const backend = { setItem: (k, v) => { mem[k] = v; }, removeItem: (k) => { delete mem[k]; }, getItem: (k) => (k in mem ? mem[k] : null) };
  const h1 = UU.createHistory(UU.createStorage(backend));
  const r = WB.pick({}, {}, h1, seeded(3));
  const h2 = UU.createHistory(UU.createStorage(backend));
  assert.ok(h2.has(r.pair.id));
  h2.reset();
  assert.strictEqual(UU.createHistory(UU.createStorage(backend)).size(), 0);
});
test('category choice is spread evenly (no category dominates)', () => {
  const hist = UU.createHistory(UU.createStorage({ setItem() {}, removeItem() {}, getItem: () => null }));
  const rng = seeded(11);
  const tally = {};
  for (let i = 0; i < 700; i++) {
    const r = WB.pick({}, {}, hist, rng);
    tally[r.pair.categoryId] = (tally[r.pair.categoryId] || 0) + 1;
  }
  const vals = Object.values(tally);
  assert.ok(vals.length >= 33, 'only ' + vals.length + ' categories seen');
  assert.ok(Math.max(...vals) < 50, 'max share ' + Math.max(...vals));
});

console.log('Role setup');
test('recommended counts are valid for every player count', () => {
  for (let n = 3; n <= 20; n++) for (const mr of [true, false]) {
    const r = E.recommend(n, mr);
    const v = E.validateCounts(n, r.undercovers, r.mrWhites, mr);
    assert.ok(v.ok, n + ' ' + mr + ' ' + v.errors);
    if (!mr) assert.strictEqual(r.mrWhites, 0);
  }
});
test('validation rejects bad configurations', () => {
  assert.ok(!E.validateCounts(2, 1, 0, true).ok);
  assert.ok(!E.validateCounts(21, 1, 0, true).ok);
  assert.ok(!E.validateCounts(5, 0, 0, true).ok, 'no impostors');
  assert.ok(!E.validateCounts(3, 3, 0, true).ok, 'no civilians');
  assert.ok(!E.validateCounts(3, 1, 1, true).ok, 'impostors not a minority');
  assert.ok(!E.validateCounts(6, 1, 1, false).ok, 'mr white disabled');
  assert.ok(!E.validateCounts(5, -1, 1, true).ok);
  assert.ok(E.validateCounts(3, 1, 0, true).ok);
  assert.ok(E.validateCounts(20, 9, 0, true).ok);
  assert.ok(!E.validateCounts(20, 10, 0, true).ok);
});
test('every role mode starts valid games for 3-20 players', () => {
  for (const mode of ['auto', 'random']) for (let n = 3; n <= 20; n++) for (let s = 1; s <= 6; s++) {
    const g = newGame(n, { roleMode: mode }, s * 17 + n);
    const c = E.counts(g);
    assert.strictEqual(c.total, n);
    assert.ok(c.civilians >= 1 && c.impostors >= 1 && c.impostors < c.civilians);
  }
});
test('manual role counts are honoured', () => {
  const g = newGame(10, { roleMode: 'manual', undercovers: 3, mrWhites: 1 }, 5);
  const c = E.counts(g);
  same([c.civilians, c.undercover, c.mrwhite], [6, 3, 1]);
});
test('Mr. White disabled never produces a Mr. White (even in random mode)', () => {
  for (let s = 1; s < 60; s++) {
    const g = newGame(12, { roleMode: 'random', mrWhiteEnabled: false }, s);
    assert.strictEqual(E.counts(g).mrwhite, 0);
  }
});
test('words: civilians share one word, undercovers the other, Mr. White none', () => {
  for (let s = 1; s < 40; s++) {
    const g = newGame(9, { roleMode: 'manual', undercovers: 2, mrWhites: 2 }, s);
    const civ = new Set(), und = new Set();
    for (const p of g.players) {
      if (p.role === 'civilian') civ.add(p.word);
      else if (p.role === 'undercover') und.add(p.word);
      else assert.strictEqual(p.word, null);
    }
    assert.strictEqual(civ.size, 1);
    assert.strictEqual(und.size, 1);
    assert.notStrictEqual([...civ][0], [...und][0]);
    assert.strictEqual([...civ][0], g.words.civilian);
  }
});
test('both word orders occur (no fixed civilian/undercover side)', () => {
  const seen = new Set();
  for (let s = 1; s < 40; s++) seen.add(newGame(5, {}, s).words.civilian);
  assert.strictEqual(seen.size, 2);
});

/* helpers to drive a game */
function runReveal(g, rng) { while (g.phase === 'roles') E.finishRoleReveal(g, rng); }
function voteAll(g, chooser) {
  E.startVoting(g);
  while (g.phase === 'vote') {
    const v = E.currentVoter(g);
    const opts = E.optionsFor(g, v);
    assert.ok(!opts.includes(v), 'self vote offered');
    if (E.castVote(g, v, chooser(v, opts))) E.finishVote(g, seeded(99));
  }
}

console.log('Round flow');
test('role reveal walks every player once, then starts a round', () => {
  const g = newGame(6, {}, 2);
  const rng = seeded(4);
  for (let i = 0; i < 6; i++) { assert.strictEqual(g.phase, 'roles'); assert.strictEqual(g.revealIndex, i); E.finishRoleReveal(g, rng); }
  assert.strictEqual(g.phase, 'describe');
  assert.strictEqual(g.describe.order.length, 6);
});
test('Mr. White never speaks first while others are alive', () => {
  for (let s = 1; s < 80; s++) {
    const g = newGame(8, { roleMode: 'manual', undercovers: 1, mrWhites: 2 }, s);
    runReveal(g, seeded(s));
    assert.notStrictEqual(g.players[g.describe.order[0]].role, 'mrwhite');
  }
});
test('cannot vote for self, out of turn, or for non-candidates', () => {
  const g = newGame(5, {}, 3);
  runReveal(g, seeded(1));
  E.startVoting(g);
  const v = E.currentVoter(g);
  assert.throws(() => E.castVote(g, v, v));
  assert.throws(() => E.castVote(g, (v + 1) % 5, v));
  assert.throws(() => E.castVote(g, v, 99));
});

console.log('Voting, ties and elimination');
test('majority vote eliminates the most-voted player', () => {
  const g = newGame(5, { roleMode: 'manual', undercovers: 1, mrWhites: 0 }, 8);
  runReveal(g, seeded(1));
  voteAll(g, (v, opts) => (opts.includes(0) ? 0 : opts[0]));
  assert.strictEqual(g.phase, 'tally');
  assert.strictEqual(g.tally.action, 'eliminate');
  assert.strictEqual(g.tally.eliminatedId, 0);
  E.continueFromTally(g, seeded(1));
  assert.strictEqual(g.players[0].alive, false);
  assert.strictEqual(g.phase, 'eliminate');
});
function tieVotes(g) { // players 0 and 1 vote for each other, the rest split 2/2 -> tie
  return (v, opts) => {
    if (v === 0) return 1;
    if (v === 1) return 0;
    return v % 2 === 0 ? 0 : 1;
  };
}
test('tie + revote: only tied players on the ballot, then random if tied again', () => {
  const g = newGame(7, { tieRule: 'revote', roleMode: 'manual', undercovers: 2, mrWhites: 0 }, 9);
  runReveal(g, seeded(1));
  voteAll(g, (v) => { const o = E.optionsFor(g, v); const pref = [v % 2 === 0 ? 1 : 0]; return o.includes(pref[0]) ? pref[0] : o[0]; });
  // Build a guaranteed tie manually instead:
  const g2 = newGame(4, { tieRule: 'revote', roleMode: 'manual', undercovers: 1, mrWhites: 0 }, 9);
  runReveal(g2, seeded(1));
  E.startVoting(g2);
  const plan = { 0: 1, 1: 0, 2: 1, 3: 0 };
  for (const v of [0, 1, 2, 3]) if (E.castVote(g2, v, plan[v])) E.finishVote(g2, seeded(5));
  assert.ok(g2.tally.tie);
  assert.strictEqual(g2.tally.action, 'revote');
  E.continueFromTally(g2, seeded(5));
  assert.strictEqual(g2.phase, 'vote');
  same(g2.vote.candidates.slice().sort(), [0, 1]);
  same(E.optionsFor(g2, 0), [1]);
  same(E.optionsFor(g2, 2).sort(), [0, 1]);
  for (const v of [0, 1, 2, 3]) if (E.castVote(g2, v, plan[v])) E.finishVote(g2, seeded(5));
  assert.strictEqual(g2.tally.action, 'random');
  assert.ok([0, 1].includes(g2.tally.eliminatedId));
});
test('tie + random rule eliminates one of the tied players', () => {
  const g = newGame(4, { tieRule: 'random', roleMode: 'manual', undercovers: 1, mrWhites: 0 }, 2);
  runReveal(g, seeded(1));
  E.startVoting(g);
  const plan = { 0: 1, 1: 0, 2: 1, 3: 0 };
  for (const v of [0, 1, 2, 3]) if (E.castVote(g, v, plan[v])) E.finishVote(g, seeded(5));
  assert.strictEqual(g.tally.action, 'random');
  assert.ok(g.tally.leaders.includes(g.tally.eliminatedId));
});
test('tie + no-elimination: round repeats, after 2 stalemates somebody goes', () => {
  const g = newGame(4, { tieRule: 'none', roleMode: 'manual', undercovers: 1, mrWhites: 0 }, 2);
  runReveal(g, seeded(1));
  const plan = { 0: 1, 1: 0, 2: 1, 3: 0 };
  for (let k = 0; k < 2; k++) {
    E.startVoting(g);
    for (const v of [0, 1, 2, 3]) if (E.castVote(g, v, plan[v])) E.finishVote(g, seeded(5));
    assert.strictEqual(g.tally.action, 'none');
    E.continueFromTally(g, seeded(5));
    assert.strictEqual(g.phase, 'describe');
    assert.strictEqual(E.counts(g).total, 4);
  }
  E.startVoting(g);
  for (const v of [0, 1, 2, 3]) if (E.castVote(g, v, plan[v])) E.finishVote(g, seeded(5));
  assert.strictEqual(g.tally.action, 'random');
});

console.log('Win conditions');
function forceOut(g, ids) { for (const id of ids) { E.quickEliminate(g, id, seeded(1)); E.afterReveal(g, seeded(1)); if (g.phase === 'guess') { E.submitGuess(g, 'definitely wrong zzz'); E.afterGuess(g, seeded(1)); } } }
test('Civilians win when every Undercover and Mr. White is out', () => {
  const g = newGame(7, { roleMode: 'manual', undercovers: 2, mrWhites: 1 }, 4);
  runReveal(g, seeded(1));
  forceOut(g, g.players.filter((p) => p.role !== 'civilian').map((p) => p.id));
  assert.strictEqual(g.phase, 'result');
  assert.strictEqual(g.winner.team, 'civilians');
});
test('Mr. White wins instantly with a correct guess', () => {
  const g = newGame(6, { roleMode: 'manual', undercovers: 1, mrWhites: 1 }, 6);
  runReveal(g, seeded(1));
  const mw = g.players.find((p) => p.role === 'mrwhite');
  E.quickEliminate(g, mw.id, seeded(1));
  E.afterReveal(g, seeded(1));
  assert.strictEqual(g.phase, 'guess');
  assert.strictEqual(E.submitGuess(g, '  ' + g.words.civilian.toUpperCase() + ' '), true);
  assert.strictEqual(g.phase, 'guessResult');
  E.afterGuess(g, seeded(1));
  assert.strictEqual(g.phase, 'result');
  assert.strictEqual(g.winner.team, 'mrwhite');
  same(g.winner.winnerIds, [mw.id]);
});
test('wrong Mr. White guess: game continues (or civilians win if nobody is left)', () => {
  const g = newGame(7, { roleMode: 'manual', undercovers: 1, mrWhites: 1 }, 6);
  runReveal(g, seeded(1));
  const mw = g.players.find((p) => p.role === 'mrwhite');
  E.quickEliminate(g, mw.id, seeded(1)); E.afterReveal(g, seeded(1));
  assert.strictEqual(E.submitGuess(g, 'banana split'), false);
  E.afterGuess(g, seeded(1));
  assert.strictEqual(g.phase, 'describe');
  assert.strictEqual(g.round, 2);
  const uc = g.players.find((p) => p.role === 'undercover');
  E.quickEliminate(g, uc.id, seeded(1)); E.afterReveal(g, seeded(1));
  assert.strictEqual(g.winner.team, 'civilians');
});
test('guess matching: case, spaces, articles, plurals, one typo on long words', () => {
  const ok = (g, a) => assert.ok(E.isGuessCorrect(g, a), g + ' ~ ' + a);
  const no = (g, a) => assert.ok(!E.isGuessCorrect(g, a), g + ' !~ ' + a);
  ok('tiger', 'Tiger'); ok(' ICE   cream ', 'Ice Cream'); ok('icecream', 'Ice Cream');
  ok('matrix', 'The Matrix'); ok('tigers', 'Tiger'); ok('Domino s', "Domino's"); ok('Elephnt', 'Elephant');
  no('lion', 'Tiger'); no('', 'Tiger'); no('cat', 'cap'); no('Venus', 'Venue');
});
test('Undercover win (majority rule): impostors equal Civilians', () => {
  const g = newGame(5, { roleMode: 'manual', undercovers: 2, mrWhites: 0, winRule: 'parity' }, 3);
  runReveal(g, seeded(1));
  const civs = g.players.filter((p) => p.role === 'civilian').map((p) => p.id);
  forceOut(g, [civs[0]]);          // 2 civ vs 2 uc -> parity
  assert.strictEqual(g.phase, 'result');
  assert.strictEqual(g.winner.team, 'undercover');
  assert.strictEqual(g.winner.reason, 'majority');
});
test('Undercover win (final two rule): needs 2 players left', () => {
  const g = newGame(6, { roleMode: 'manual', undercovers: 2, mrWhites: 0, winRule: 'finalTwo' }, 3);
  runReveal(g, seeded(1));
  const civs = g.players.filter((p) => p.role === 'civilian').map((p) => p.id);
  forceOut(g, [civs[0], civs[1]]);  // 2 civ + 2 uc remain: not over yet
  assert.strictEqual(g.phase, 'describe');
  forceOut(g, [civs[2]]);           // 1 civ + 2 uc = 3 players: still going
  assert.strictEqual(g.phase, 'describe');
  forceOut(g, [g.players.find((p) => p.role === 'undercover').id]); // civ vs uc = 2 left
  assert.strictEqual(g.phase, 'result');
  assert.strictEqual(g.winner.team, 'undercover');
});
test('Undercover win (final three rule)', () => {
  const g = newGame(6, { roleMode: 'manual', undercovers: 2, mrWhites: 0, winRule: 'finalThree' }, 3);
  runReveal(g, seeded(1));
  const civs = g.players.filter((p) => p.role === 'civilian').map((p) => p.id);
  forceOut(g, [civs[0], civs[1]]);
  assert.strictEqual(g.phase, 'describe');
  forceOut(g, [civs[2]]);
  assert.strictEqual(g.phase, 'result');
  assert.strictEqual(g.winner.team, 'undercover');
});
test('only Mr. White left alive at the end -> Mr. White team wins', () => {
  const g = newGame(5, { roleMode: 'manual', undercovers: 1, mrWhites: 1, winRule: 'parity' }, 3);
  runReveal(g, seeded(1));
  const uc = g.players.find((p) => p.role === 'undercover').id;
  const civs = g.players.filter((p) => p.role === 'civilian').map((p) => p.id);
  forceOut(g, [uc]);               // 3 civ vs 1 Mr. White
  assert.strictEqual(g.phase, 'describe');
  forceOut(g, [civs[0]]);          // 2 civ vs 1 Mr. White
  assert.strictEqual(g.phase, 'describe');
  forceOut(g, [civs[1]]);          // 1 civ vs 1 Mr. White -> majority rule
  assert.strictEqual(g.phase, 'result');
  assert.strictEqual(g.winner.team, 'mrwhite');
  assert.strictEqual(g.winner.reason, 'majority');
});

console.log('Role privacy');
test('serialised public view needs no secrets: roles only visible via player records', () => {
  const g = newGame(6, {}, 3);
  const snap = JSON.parse(JSON.stringify(g));
  same(snap.players.map((p) => p.role), g.players.map((p) => p.role));
});

console.log('Monte-Carlo: 3000 random full games');
test('random games always terminate with a valid winner', () => {
  let games = 0;
  const wins = { civilians: 0, undercover: 0, mrwhite: 0 };
  for (let s = 1; s <= 3000; s++) {
    const rng = seeded(s * 31);
    const n = 3 + rng.int(18);
    const g = newGame(n, {
      roleMode: rng.pick(['auto', 'random']), tieRule: rng.pick(['revote', 'random', 'none']),
      winRule: rng.pick(['parity', 'finalTwo', 'finalThree']), mrWhiteEnabled: rng.chance(0.7),
    }, s);
    const sim = seeded(s * 7 + 1);
    runReveal(g, sim);
    let guard = 0;
    while (g.phase !== 'result') {
      assert.ok(++guard < 6000, 'game did not end (seed ' + s + ')');
      if (g.phase === 'describe') { E.startVoting(g); continue; }
      if (g.phase === 'vote') {
        const v = E.currentVoter(g);
        if (E.castVote(g, v, sim.pick(E.optionsFor(g, v)))) E.finishVote(g, sim);
      } else if (g.phase === 'tally') E.continueFromTally(g, sim);
      else if (g.phase === 'eliminate') E.afterReveal(g, sim);
      else if (g.phase === 'guess') {
        const lucky = sim.chance(0.2);
        E.submitGuess(g, lucky ? g.words.civilian : 'nope nope');
      } else if (g.phase === 'guessResult') E.afterGuess(g, sim);
      else throw new Error('stuck in ' + g.phase);
    }
    assert.ok(g.winner && g.winner.winnerIds.length >= 1);
    wins[g.winner.team]++;
    games++;
  }
  console.log('      ', games, 'games ->', JSON.stringify(wins));
  assert.ok(wins.civilians > 0 && wins.undercover > 0 && wins.mrwhite > 0);
});

console.log('\n' + passed + ' tests passed' + (process.exitCode ? ' — WITH FAILURES' : ''));
