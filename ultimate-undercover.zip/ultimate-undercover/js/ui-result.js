/* Victory screen. */
(function (root) {
  'use strict';
  const UU = root.UU;
  const ui = UU.ui;
  const { h, ROLE_NAME, ROLE_CLS } = ui;

  const TITLES = { civilians: 'Civilians Win!', undercover: 'Undercover Wins!', mrwhite: 'Mr. White Wins!' };
  const EMBLEM = { civilians: 'civilian', undercover: 'undercover', mrwhite: 'mrwhite' };
  const COLORS = {
    civilians: ['#3ea8ff', '#7c5cff', '#2ee6a6', '#ffffff'],
    undercover: ['#c46bff', '#ff4fd8', '#7c5cff', '#ffffff'],
    mrwhite: ['#eef0ff', '#ffc857', '#36a2ff', '#ff4fd8'],
  };

  function reasonText(g) {
    const w = g.winner;
    const word = '"' + g.words.civilian + '"';
    if (w.team === 'civilians') return 'Every Undercover and Mr. White has been found out.';
    if (w.reason === 'guess') return 'Mr. White correctly guessed the Civilians\' word, ' + word + '!';
    const why = {
      majority: 'The impostors now equal the Civilians in number.',
      'final-two': 'Only two players are left and an impostor is still hiding.',
      'final-three': 'Only three players are left and an impostor is still hiding.',
      'no-civilians': 'No Civilians are left.',
    }[w.reason] || '';
    return w.team === 'mrwhite' ? 'Mr. White survived to the end. ' + why : why;
  }

  function recap(g) {
    const name = (id) => g.players[id].name;
    return g.log.map((e) => {
      if (e.type === 'out') return 'Round ' + e.round + ': ' + name(e.id) + ' was voted out (' + ROLE_NAME[e.role] + ').';
      if (e.type === 'guess') return 'Round ' + e.round + ': ' + name(e.id) + (e.text ? ' guessed "' + e.text + '" — ' + (e.correct ? 'correct!' : 'wrong.') : ' passed on the guess.');
      return 'Round ' + e.round + ': tie between ' + e.ids.map(name).join(' & ') + ' — nobody left.';
    });
  }

  ui.screens.result = function () {
    const g = ui.game;
    const w = g.winner;
    const winners = new Set(w.winnerIds);
    const team = w.team;

    const players = g.players.map((p) =>
      h('div', { class: 'role-line' },
        h('div', { class: 'who' }, h('span', { class: 'ico c-' + ROLE_CLS[p.role], html: UU.Icons.role[p.role] }),
          h('div', null, h('div', null, p.name), h('div', { class: 'small c-' + ROLE_CLS[p.role] }, ROLE_NAME[p.role] + (p.word ? ' · ' + p.word : '')))),
        h('div', { class: 'row' }, winners.has(p.id) ? h('span', { class: 'tag win' }, '★ Winner') : null, !p.alive ? h('span', { class: 'tag out' }, 'Out') : null)));

    const log = recap(g);

    setTimeout(() => {
      if (ui.name !== 'result') return;
      ui.confetti(COLORS[team]);
      UU.Sound.play(team === 'civilians' ? 'win' : 'reveal');
    }, 250);

    return ui.screenEl({},
      h('div', { class: 'banner ' + team },
        ui.emblem(EMBLEM[team]),
        h('div', { class: 'eyebrow' }, 'Game over · ' + ui.plural(g.round, 'round')),
        h('h1', { class: 'grad' }, TITLES[team]),
        h('p', { class: 'muted' }, reasonText(g))),
      h('div', { class: 'words' },
        h('div', { class: 'wbox' }, h('small', { class: 'c-civ' }, 'Civilian word'), h('b', null, g.words.civilian)),
        h('div', { class: 'wbox' }, h('small', { class: 'c-und' }, 'Undercover word'), h('b', null, g.words.undercover))),
      h('p', { class: 'muted small center-text' }, g.words.category + ' · ' + g.words.difficulty),
      ui.card('Final roles', null, 'users', players),
      log.length ? ui.card('What happened', null, 'timer', h('div', { class: 'timeline' }, log.map((t) => h('div', null, t)))) : null,
      ui.dock(false,
        ui.btn('Return home', { icon: 'home', onClick: () => { ui.game = null; ui.saveGame(); ui.go('home'); } }),
        ui.btn('Play again', {
          kind: 'primary', icon: 'refresh',
          onClick: () => {
            const names = (ui.lastRun && ui.lastRun.names) || g.players.map((p) => p.name);
            const err = ui.launch(names);
            if (err) { UU.Sound.play('error'); ui.toast(err); ui.game = null; ui.go('setup'); }
          },
        })));
  };
})(typeof window !== 'undefined' ? window : globalThis);
