/* Shared helpers: hashing, text normalisation, random numbers, storage. No DOM here. */
(function (root) {
  'use strict';
  const UU = (root.UU = root.UU || {});

  /* 53-bit string hash (cyrb53). Used to give every word pair a stable id. */
  function cyrb53(str, seed) {
    let h1 = 0xdeadbeef ^ (seed || 0);
    let h2 = 0x41c6ce57 ^ (seed || 0);
    for (let i = 0; i < str.length; i++) {
      const ch = str.charCodeAt(i);
      h1 = Math.imul(h1 ^ ch, 2654435761);
      h2 = Math.imul(h2 ^ ch, 1597334677);
    }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
    return 4294967296 * (2097151 & h2) + (h1 >>> 0);
  }

  /* lower-case, strip accents and punctuation, collapse spaces */
  function norm(s) {
    return String(s == null ? '' : s)
      .toLowerCase()
      .normalize('NFKD')
      .replace(/[̀-ͯ]/g, '')
      .replace(/[^a-z0-9]+/g, ' ')
      .trim();
  }

  function levenshtein(a, b) {
    if (a === b) return 0;
    if (!a.length) return b.length;
    if (!b.length) return a.length;
    let prev = new Array(b.length + 1);
    for (let j = 0; j <= b.length; j++) prev[j] = j;
    for (let i = 1; i <= a.length; i++) {
      const cur = [i];
      for (let j = 1; j <= b.length; j++) {
        cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
      }
      prev = cur;
    }
    return prev[b.length];
  }

  /* ---------- random numbers ---------- */
  function makeRng(u32) {
    return {
      float() { return u32() / 4294967296; },
      /* uniform integer in [0, n) without modulo bias */
      int(n) {
        if (n <= 1) return 0;
        const limit = 4294967296 - (4294967296 % n);
        let x;
        do { x = u32(); } while (x >= limit);
        return x % n;
      },
      pick(arr) { return arr[this.int(arr.length)]; },
      chance(p) { return this.float() < p; },
      shuffle(arr) {
        const a = arr.slice();
        for (let i = a.length - 1; i > 0; i--) {
          const j = this.int(i + 1);
          const t = a[i]; a[i] = a[j]; a[j] = t;
        }
        return a;
      },
    };
  }

  function cryptoRng() {
    const c = root.crypto;
    return makeRng(function () {
      if (c && c.getRandomValues) {
        const a = new Uint32Array(1);
        c.getRandomValues(a);
        return a[0];
      }
      return Math.floor(Math.random() * 4294967296);
    });
  }

  /* Deterministic generator, used by the automated tests. */
  function seededRng(seed) {
    let t = seed >>> 0;
    return makeRng(function () {
      t = (t + 0x6d2b79f5) >>> 0;
      let r = Math.imul(t ^ (t >>> 15), 1 | t);
      r = (r + Math.imul(r ^ (r >>> 7), 61 | r)) ^ r;
      return ((r ^ (r >>> 14)) >>> 0);
    });
  }

  /* ---------- storage (localStorage with in-memory fallback) ---------- */
  function createStorage(backend) {
    const mem = {};
    let ls = null;
    try {
      const b = backend || root.localStorage;
      const k = '__uu_probe__';
      b.setItem(k, '1');
      b.removeItem(k);
      ls = b;
    } catch (e) { ls = null; }
    return {
      persistent: !!ls,
      get(key, fallback) {
        try {
          const raw = ls ? ls.getItem(key) : mem[key];
          return raw == null ? fallback : JSON.parse(raw);
        } catch (e) { return fallback; }
      },
      set(key, value) {
        const raw = JSON.stringify(value);
        try {
          if (ls) ls.setItem(key, raw); else mem[key] = raw;
          return true;
        } catch (e) { mem[key] = raw; return false; }
      },
      remove(key) {
        try { if (ls) ls.removeItem(key); } catch (e) { /* ignore */ }
        delete mem[key];
      },
    };
  }

  UU.util = { cyrb53, norm, levenshtein, makeRng, seededRng };
  UU.rng = cryptoRng();
  UU.createStorage = createStorage;
  UU.storage = createStorage();
  if (typeof module !== 'undefined' && module.exports) module.exports = UU;
})(typeof window !== 'undefined' ? window : globalThis);
