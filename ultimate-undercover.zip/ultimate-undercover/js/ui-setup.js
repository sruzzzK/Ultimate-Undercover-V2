/* Setup screen: players, roles, words — plus the function that actually launches a game. */
(function (root) {
  'use strict';
  const UU = root.UU;
  const ui = UU.ui;
  const { h } = ui;
  const E = UU.Engine;

  ui.initSetup = function () {
    const saved = UU.Settings.loadNames();
    ui.setup = { names: Array.from({ length: 20 }, (_, i) => saved[i] || ''), rulesOpen: false };
  };

  /* keep manual role counts valid for the current player count */
  function clampManual() {
    const S = ui.S;
    const max = E.maxImpostors(S.playerCount);
    if (!S.mrWhiteEnabled) S.mrWhites = 0;
    S.undercovers = Math.max(0, Math.min(S.undercovers, max));
    S.mrWhites = Math.max(0, Math.min(S.mrWhites, max - S.undercovers));
    if (S.undercovers + S.mrWhites < 1) S.undercovers = 1;
  }

  function currentNames() {
    const n = ui.S.playerCount;
    return Array.from({ length: n }, (_, i) => (ui.setup.names[i] || '').trim().replace(/\s+/g, ' ') || 'Player ' + (i + 1));
  }

  function wordFilter() { return { categories: ui.S.categories, difficulty: ui.S.difficulty }; }

  /* Everything that could stop a game from starting. */
  function validate() {
    const S = ui.S;
    const errors = [];
    const names = currentNames();
    const seen = new Map();
    const dups = new Set();
    names.forEach((nm, i) => {
      const k = nm.toLowerCase();
      if (seen.has(k)) { dups.add(i); dups.add(seen.get(k)); } else seen.set(k, i);
    });
    if (dups.size) errors.push('Every player needs a different name.');
    let counts = null;
    if (S.roleMode === 'auto') counts = E.recommend(S.playerCount, S.mrWhiteEnabled);
    if (S.roleMode === 'manual') counts = { undercovers: S.undercovers, mrWhites: S.mrWhiteEnabled ? S.mrWhites : 0 };
    if (counts) {
      const v = E.validateCounts(S.playerCount, counts.undercovers, counts.mrWhites, S.mrWhiteEnabled);
      v.errors.forEach((e) => errors.push(e));
    }
    let action = null;
    if (!S.categories.length) errors.push('Pick at least one word category.');
    else {
      const st = UU.WordBank.stats(wordFilter(), UU.history);
      if (st.total === 0) errors.push('No word pairs match this category + difficulty combination. Try "Any" difficulty.');
      else if (st.fresh === 0 && !S.allowRecycle) {
        errors.push('Every matching pair has already been played.');
        action = 'reset';
      }
    }
    return { errors, names, dups, counts, action };
  }

  /* Launch a game with the given names. Returns an error string, or null on success. */
  ui.launch = function (names) {
    const S = ui.S;
    const picked = UU.WordBank.pick(wordFilter(), { allowRecycle: S.allowRecycle }, UU.history, UU.rng);
    if (picked.error) {
      return picked.error === 'exhausted'
        ? 'Every matching pair has been played — reset the word history or allow pairs to return.'
        : 'No word pairs match your category and difficulty choice.';
    }
    try {
      ui.game = E.startGame({ names, settings: S, pair: picked.pair, rng: UU.rng });
    } catch (e) {
      return e.message;
    }
    ui.lastRun = { names };
    if (picked.recycled) ui.toast('All pairs in this selection were played — history restarted for it');
    ui.sync();
    return null;
  };

  ui.screens.setup = function () {
    const S = ui.S;
    const WB = UU.WordBank;
    const su = ui.setup;
    const n = S.playerCount;
    const rerender = ui.refresh;
    const set = (k, v) => { S[k] = v; if (k === 'mrWhiteEnabled' || k === 'roleMode') clampManual(); ui.saveSettings(); rerender(); };

    /* ----- status area (errors) + start button are updated in place so typing never loses focus ----- */
    const status = h('div', { class: 'stack' });
    const startBtn = ui.btn('Start game', { kind: 'primary', size: 'lg', icon: 'play', onClick: () => { startGame(); } });
    function startGame() {
      const v = validate();
      if (v.errors.length) { UU.Sound.play('error'); ui.toast(v.errors[0]); return; }
      UU.Settings.saveNames(su.names);
      const err = ui.launch(v.names);
      if (err) { UU.Sound.play('error'); ui.toast(err); updateStatus(); }
    }
    const nameInputs = [];
    function updateStatus() {
      const v = validate();
      status.textContent = '';
      v.errors.forEach((e) => status.appendChild(h('div', { class: 'notice err' }, e)));
      if (v.action === 'reset') {
        status.appendChild(ui.btn('Reset word history', { kind: 'danger', size: 'sm', icon: 'refresh', onClick: () => { UU.history.reset(); ui.toast('Word history cleared'); rerender(); } }));
      }
      startBtn.disabled = v.errors.length > 0;
      nameInputs.forEach((inp, i) => inp.classList.toggle('bad', v.dups.has(i)));
    }

    /* ----- players ----- */
    const names = h('div', { class: 'names' });
    for (let i = 0; i < n; i++) {
      const inp = h('input', {
        class: 'field', type: 'text', maxlength: '16', autocomplete: 'off', autocapitalize: 'words', spellcheck: 'false',
        placeholder: 'Player ' + (i + 1), value: su.names[i] || '', 'aria-label': 'Name of player ' + (i + 1),
        oninput: (e) => { su.names[i] = e.target.value; UU.Settings.saveNames(su.names); updateStatus(); },
      });
      nameInputs.push(inp);
      names.appendChild(h('div', { class: 'name-wrap' }, h('i', null, String(i + 1)), inp));
    }
    const playersCard = ui.card('Players', 'Add everyone in the order you sit around the table.', 'users',
      h('div', { class: 'row between', style: { marginBottom: '12px' } },
        h('div', null, h('b', null, ui.plural(n, 'player')), h('div', { class: 'muted small' }, '3 to 20 players')),
        ui.stepper(n, E.MIN_PLAYERS, E.MAX_PLAYERS, (v) => set('playerCount', v), 'Number of players')),
      names);

    /* ----- roles ----- */
    clampManual();
    const v0 = validate();
    const counts = v0.counts;
    const bar = h('div', { class: 'dist-bar', 'aria-hidden': 'true' });
    const legend = h('div', { class: 'legend' });
    if (counts) {
      const civ = n - counts.undercovers - counts.mrWhites;
      [['bg-civ', civ], ['bg-und', counts.undercovers], ['bg-mrw', counts.mrWhites]].forEach(([c, v]) => {
        if (v > 0) bar.appendChild(h('i', { class: c, style: { flex: String(v) } }));
      });
      legend.appendChild(h('span', { class: 'c-civ' }, h('i', { class: 'dot bg-civ' }), 'Civilians ' + Math.max(0, civ)));
      legend.appendChild(h('span', { class: 'c-und' }, h('i', { class: 'dot bg-und' }), 'Undercover ' + counts.undercovers));
      if (S.mrWhiteEnabled) legend.appendChild(h('span', { class: 'c-mrw' }, h('i', { class: 'dot bg-mrw' }), 'Mr. White ' + counts.mrWhites));
    }
    const max = E.maxImpostors(n);
    const rolesCard = ui.card('Roles', null, 'lock',
      h('div', { class: 'stack' },
        ui.seg([{ value: 'auto', label: 'Auto' }, { value: 'manual', label: 'Manual' }, { value: 'random', label: 'Random' }], S.roleMode, (v) => set('roleMode', v)),
        h('p', { class: 'muted small' }, {
          auto: 'Balanced roles picked for your group size.',
          manual: 'Choose exactly how many of each role.',
          random: 'Surprise! The number of impostors is secretly random every game, so nobody knows how many to hunt.',
        }[S.roleMode]),
        ui.toggle('Include Mr. White', 'A player with no word who must bluff — and can win with a lucky guess.', S.mrWhiteEnabled, (v) => set('mrWhiteEnabled', v)),
        S.roleMode === 'manual'
          ? h('div', { class: 'stack' },
            h('div', { class: 'row between' }, h('b', { class: 'c-und' }, 'Undercovers'), ui.stepper(S.undercovers, 0, Math.max(0, max - S.mrWhites), (v) => set('undercovers', v), 'Undercovers')),
            S.mrWhiteEnabled ? h('div', { class: 'row between' }, h('b', { class: 'c-mrw' }, 'Mr. Whites'), ui.stepper(S.mrWhites, 0, Math.max(0, max - S.undercovers), (v) => set('mrWhites', v), 'Mr. Whites')) : null,
            h('p', { class: 'muted small' }, 'Civilians are calculated automatically. Up to ' + max + ' impostors are allowed for ' + n + ' players.'))
          : null,
        counts ? [bar, legend] : h('div', { class: 'notice' }, 'Between 1 and ' + max + ' impostors' + (S.mrWhiteEnabled ? ' (Undercover and/or Mr. White)' : ' (Undercover)') + ' — revealed only at the end.')));

    /* ----- words ----- */
    const stats = S.categories.length ? WB.stats(wordFilter(), UU.history) : { total: 0, fresh: 0, used: 0 };
    const allIds = WB.categories.map((c) => c.id);
    const toggleCat = (id) => {
      const on = S.categories.includes(id);
      S.categories = on ? S.categories.filter((x) => x !== id) : allIds.filter((x) => x === id || S.categories.includes(x));
      ui.saveSettings(); rerender();
    };
    const wordsCard = ui.card('Words', 'Choose how hard the pairs are and which topics appear.', 'dice',
      h('div', { class: 'stack' },
        ui.seg([{ value: 'all', label: 'Any' }, { value: 'easy', label: 'Easy' }, { value: 'medium', label: 'Medium' }, { value: 'hard', label: 'Hard' }], S.difficulty, (v) => set('difficulty', v)),
        h('div', { class: 'row between' },
          h('b', null, S.categories.length === allIds.length ? 'All categories' : S.categories.length + ' of ' + allIds.length + ' categories'),
          h('div', { class: 'row' },
            ui.btn('All', { size: 'sm', onClick: () => { S.categories = allIds.slice(); ui.saveSettings(); rerender(); } }),
            ui.btn('None', { size: 'sm', onClick: () => { S.categories = []; ui.saveSettings(); rerender(); } }))),
        h('div', { class: 'chips' }, WB.categories.map((c) =>
          h('button', { type: 'button', class: 'chip' + (S.categories.includes(c.id) ? ' on' : ''), 'aria-pressed': String(S.categories.includes(c.id)), onclick: () => { UU.Sound.play('tap'); toggleCat(c.id); } },
            c.icon + ' ' + c.name))),
        h('div', { class: 'notice' + (stats.fresh === 0 ? ' warn' : ' ok') },
          h('b', null, ui.fmt(stats.fresh)), ' fresh pairs · ', ui.fmt(stats.total), ' match your choice',
          stats.used ? ' (' + ui.fmt(stats.used) + ' played before)' : '')));

    /* ----- rules (collapsible) ----- */
    const rules = h('details', { class: 'card', ontoggle: (e) => { su.rulesOpen = e.target.open; } },
      h('summary', null, h('span', { class: 'row' }, ui.icon('sliders'), 'Game rules & timers'), ui.icon('chevron')),
      ui.rulesPanel(rerender));
    if (su.rulesOpen) rules.setAttribute('open', '');

    const el = ui.screenEl({ wide: true },
      ui.topbar('Game setup', {
        eyebrow: 'New game', back: () => ui.go('home'),
        right: ui.iconBtn('sliders', 'Settings', () => ui.go('settings', { from: 'setup' })),
      }),
      h('div', { class: 'two-col' },
        h('div', { class: 'stack' }, playersCard),
        h('div', { class: 'stack' }, rolesCard, wordsCard)),
      rules,
      status,
      ui.dock(true, startBtn));
    updateStatus();
    return el;
  };
})(typeof window !== 'undefined' ? window : globalThis);
