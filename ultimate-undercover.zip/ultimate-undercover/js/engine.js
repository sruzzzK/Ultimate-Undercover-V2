/* Game engine: roles, rounds, voting, ties, elimination, Mr. White guess and win rules.
 * Pure logic — no DOM, no storage — so it can be tested in Node. State is plain JSON. */
(function (root) {
  'use strict';
  const UU = (root.UU = root.UU || {});
  const { norm, levenshtein } = UU.util;

  const MIN_PLAYERS = 3;
  const MAX_PLAYERS = 20;
  const ROLE = { CIVILIAN: 'civilian', UNDERCOVER: 'undercover', MRWHITE: 'mrwhite' };

  const WIN_RULES = {
    parity: {
      name: 'Majority',
      text: 'Impostors win as soon as they equal or outnumber the Civilians.',
    },
    finalTwo: {
      name: 'Final two',
      text: 'Impostors win if one of them is still alive when only 2 players remain.',
    },
    finalThree: {
      name: 'Final three',
      text: 'Impostors win if one of them is still alive when only 3 players remain.',
    },
  };
  const TIE_RULES = {
    revote: {
      name: 'Re-vote',
      text: 'Only the tied players stay on the ballot. If it ties again, one is picked at random.',
    },
    random: { name: 'Random', text: 'One of the tied players is picked at random.' },
    none: {
      name: 'No elimination',
      text: 'Nobody leaves; play another description round. After 2 stalemates in a row a random tied player goes.',
    },
  };

  /* ---------- role counts ---------- */
  function maxImpostors(n) { return Math.floor((n - 1) / 2); }

  function recommend(n, mrWhiteEnabled) {
    const bad = Math.min(Math.max(1, Math.round(n / 4)), maxImpostors(n));
    let mw = 0;
    if (mrWhiteEnabled) mw = bad >= 5 ? 2 : bad >= 2 ? 1 : 0;
    return { undercovers: bad - mw, mrWhites: mw };
  }

  function validateCounts(n, undercovers, mrWhites, mrWhiteEnabled) {
    const errors = [];
    const intOk = (x) => Number.isInteger(x) && x >= 0;
    if (!Number.isInteger(n) || n < MIN_PLAYERS || n > MAX_PLAYERS) {
      errors.push('Player count must be between ' + MIN_PLAYERS + ' and ' + MAX_PLAYERS + '.');
    }
    if (!intOk(undercovers) || !intOk(mrWhites)) errors.push('Role counts must be whole numbers.');
    if (errors.length) return { ok: false, errors, civilians: 0 };
    if (!mrWhiteEnabled && mrWhites > 0) errors.push('Mr. White is switched off.');
    const civilians = n - undercovers - mrWhites;
    if (undercovers + mrWhites < 1) errors.push('Add at least one Undercover or Mr. White.');
    if (civilians < 1) errors.push('There must be at least one Civilian.');
    else if (undercovers + mrWhites >= civilians) {
      errors.push('Impostors must start as a minority (at most ' + maxImpostors(n) + ' for ' + n + ' players).');
    }
    return { ok: errors.length === 0, errors, civilians };
  }

  /* Works out the role counts for a game from the settings. */
  function resolveCounts(settings, n, rng) {
    const mrOn = !!settings.mrWhiteEnabled;
    if (settings.roleMode === 'manual') {
      return { undercovers: settings.undercovers, mrWhites: mrOn ? settings.mrWhites : 0 };
    }
    if (settings.roleMode === 'random') {
      const bad = 1 + rng.int(Math.max(1, maxImpostors(n)));
      let mw = 0;
      if (mrOn) for (let i = 0; i < bad; i++) if (rng.int(3) === 0) mw++;
      return { undercovers: bad - mw, mrWhites: mw };
    }
    return recommend(n, mrOn);
  }

  /* ---------- guesses ---------- */
  function compact(s) { return norm(s).replace(/^(the|a|an)\s+/, '').replace(/\s+/g, ''); }
  function isGuessCorrect(guess, answer) {
    const g = compact(guess);
    const a = compact(answer);
    if (!g || !a) return false;
    if (g === a) return true;
    if (g === a + 's' || a === g + 's' || g === a + 'es' || a === g + 'es') return true;
    if (a.length >= 7 && levenshtein(g, a) <= 1) return true; // tolerate one typo on long words
    return false;
  }

  /* ---------- state helpers ---------- */
  function player(state, id) { return state.players[id]; }
  function alive(state) { return state.players.filter((p) => p.alive); }
  function counts(state) {
    const c = { civilians: 0, undercover: 0, mrwhite: 0 };
    for (const p of state.players) if (p.alive) c[p.role === ROLE.CIVILIAN ? 'civilians' : p.role]++;
    c.impostors = c.undercover + c.mrwhite;
    c.total = c.civilians + c.impostors;
    return c;
  }

  /* ---------- starting a game ---------- */
  /* opts: { names:[...], settings, pair:{a,b,...}, rng }  — `pair` comes from the word bank */
  function startGame(opts) {
    const { names, settings, pair, rng } = opts;
    const n = names.length;
    const cnt = resolveCounts(settings, n, rng);
    const v = validateCounts(n, cnt.undercovers, cnt.mrWhites, settings.mrWhiteEnabled);
    if (!v.ok) throw new Error(v.errors.join(' '));
    const roles = [];
    for (let i = 0; i < v.civilians; i++) roles.push(ROLE.CIVILIAN);
    for (let i = 0; i < cnt.undercovers; i++) roles.push(ROLE.UNDERCOVER);
    for (let i = 0; i < cnt.mrWhites; i++) roles.push(ROLE.MRWHITE);
    const shuffled = rng.shuffle(roles);
    const swap = rng.chance(0.5);
    const civWord = swap ? pair.b : pair.a;
    const undWord = swap ? pair.a : pair.b;
    const state = {
      v: 1,
      settings: {
        roleMode: settings.roleMode,
        tieRule: settings.tieRule,
        winRule: settings.winRule,
        votingMode: settings.votingMode,
        showRoles: !!settings.showRoles,
        descSeconds: settings.descSeconds,
        voteSeconds: settings.voteSeconds,
      },
      players: names.map((name, i) => ({
        id: i,
        name,
        role: shuffled[i],
        alive: true,
        word: shuffled[i] === ROLE.CIVILIAN ? civWord : shuffled[i] === ROLE.UNDERCOVER ? undWord : null,
      })),
      words: { civilian: civWord, undercover: undWord, category: pair.category, difficulty: pair.difficulty, pairId: pair.id },
      startCounts: { civilians: v.civilians, undercovers: cnt.undercovers, mrWhites: cnt.mrWhites },
      phase: 'roles',
      revealIndex: 0,
      round: 1,
      stalemates: 0,
      describe: null,
      vote: null,
      tally: null,
      elimination: null,
      log: [],
      winner: null,
    };
    return state;
  }

  /* ---------- role distribution ---------- */
  function finishRoleReveal(state, rng) {
    state.revealIndex++;
    if (state.revealIndex >= state.players.length) beginRound(state, rng);
    return state;
  }

  /* ---------- description round ---------- */
  function beginRound(state, rng) {
    const order = alive(state).map((p) => p.id);
    const eligible = order.filter((id) => player(state, id).role !== ROLE.MRWHITE);
    const starter = (eligible.length ? rng.pick(eligible) : rng.pick(order));
    const at = order.indexOf(starter);
    state.describe = { order: order.slice(at).concat(order.slice(0, at)), index: 0 };
    state.vote = null;
    state.tally = null;
    state.elimination = null;
    state.phase = 'describe';
    return state;
  }

  /* describe.index runs 0..order.length; order.length means everyone has spoken. */
  function nextSpeaker(state) {
    const d = state.describe;
    if (d.index < d.order.length) d.index++;
    return d.index >= d.order.length;
  }

  /* ---------- voting ---------- */
  function startVoting(state, candidates, attempt) {
    state.phase = 'vote';
    state.tally = null;
    state.vote = {
      voters: alive(state).map((p) => p.id),
      index: 0,
      ballots: {},
      candidates: candidates || null,
      attempt: attempt || 0,
    };
    return state;
  }

  /* Allowed only before the first ballot of a fresh vote has been cast. */
  function backToDescribe(state) {
    if (state.phase === 'vote' && state.vote && state.vote.index === 0 && state.vote.attempt === 0) {
      state.phase = 'describe';
      state.vote = null;
    }
    return state;
  }

  function currentVoter(state) { return state.vote.voters[state.vote.index]; }

  function optionsFor(state, voterId) {
    const base = state.vote.candidates || alive(state).map((p) => p.id);
    return base.filter((id) => id !== voterId);
  }

  function castVote(state, voterId, targetId) {
    const v = state.vote;
    if (state.phase !== 'vote') throw new Error('Not in voting phase.');
    if (voterId !== currentVoter(state)) throw new Error('Not this player\'s turn to vote.');
    if (voterId === targetId) throw new Error('You cannot vote for yourself.');
    if (!optionsFor(state, voterId).includes(targetId)) throw new Error('That player is not on the ballot.');
    v.ballots[voterId] = targetId;
    v.index++;
    return v.index >= v.voters.length;
  }

  /* All ballots are in: count them and decide what happens (stored in state.tally). */
  function finishVote(state, rng) {
    const v = state.vote;
    const cands = v.candidates || alive(state).map((p) => p.id);
    const votes = {};
    cands.forEach((id) => { votes[id] = 0; });
    Object.values(v.ballots).forEach((t) => { votes[t] = (votes[t] || 0) + 1; });
    const rows = Object.keys(votes).map((id) => ({ id: Number(id), votes: votes[id] }))
      .sort((a, b) => b.votes - a.votes || a.id - b.id);
    const top = rows[0].votes;
    const leaders = rows.filter((r) => r.votes === top).map((r) => r.id);
    const t = { rows, leaders, tie: leaders.length > 1, action: 'eliminate', eliminatedId: leaders[0], attempt: v.attempt };
    if (t.tie) {
      const rule = state.settings.tieRule;
      if (rule === 'revote' && v.attempt === 0) { t.action = 'revote'; t.eliminatedId = null; }
      else if (rule === 'none' && state.stalemates < 2) { t.action = 'none'; t.eliminatedId = null; }
      else { t.action = 'random'; t.eliminatedId = rng.pick(leaders); }
    }
    state.tally = t;
    state.phase = 'tally';
    return t;
  }

  function continueFromTally(state, rng) {
    const t = state.tally;
    if (t.action === 'revote') return startVoting(state, t.leaders, 1);
    if (t.action === 'none') {
      state.stalemates++;
      state.log.push({ round: state.round, type: 'stalemate', ids: t.leaders });
      state.round++;
      return beginRound(state, rng);
    }
    return eliminate(state, t.eliminatedId, rng);
  }

  /* Quick mode: the group decided out loud, the host just taps the player. */
  function quickEliminate(state, id, rng) {
    state.tally = null;
    return eliminate(state, id, rng);
  }

  /* ---------- elimination ---------- */
  function eliminate(state, id, rng) {
    const p = player(state, id);
    if (!p || !p.alive) throw new Error('Invalid elimination.');
    p.alive = false;
    state.stalemates = 0;
    state.elimination = { id, role: p.role, round: state.round, guess: null };
    state.log.push({ round: state.round, type: 'out', id, role: p.role });
    state.phase = 'eliminate';
    return state;
  }

  /* After the role reveal: Mr. White gets a guess, everyone else goes straight on. */
  function afterReveal(state, rng) {
    if (state.elimination.role === ROLE.MRWHITE) { state.phase = 'guess'; return state; }
    return evaluate(state, rng);
  }

  function submitGuess(state, text) {
    if (state.phase !== 'guess') throw new Error('No guess expected.');
    const correct = isGuessCorrect(text, state.words.civilian);
    state.elimination.guess = { text: String(text || '').trim(), correct };
    state.log.push({ round: state.round, type: 'guess', id: state.elimination.id, text: state.elimination.guess.text, correct });
    state.phase = 'guessResult';
    return correct;
  }

  function afterGuess(state, rng) {
    if (state.elimination.guess && state.elimination.guess.correct) {
      const mw = player(state, state.elimination.id);
      state.winner = { team: 'mrwhite', reason: 'guess', winnerIds: [mw.id] };
      state.phase = 'result';
      return state;
    }
    return evaluate(state, rng);
  }

  /* ---------- win conditions ---------- */
  function checkWin(state) {
    const k = counts(state);
    const all = state.players;
    if (k.impostors === 0) {
      return { team: 'civilians', reason: 'cleared', winnerIds: all.filter((p) => p.role === ROLE.CIVILIAN).map((p) => p.id) };
    }
    const rule = state.settings.winRule;
    let reason = null;
    if (k.civilians === 0) reason = 'no-civilians';
    else if (rule === 'parity' && k.impostors >= k.civilians) reason = 'majority';
    else if (rule === 'finalTwo' && k.total <= 2) reason = 'final-two';
    else if (rule === 'finalThree' && k.total <= 3) reason = 'final-three';
    if (!reason) return null;
    if (k.undercover > 0) {
      return {
        team: 'undercover', reason,
        winnerIds: all.filter((p) => p.role === ROLE.UNDERCOVER || (p.role === ROLE.MRWHITE && p.alive)).map((p) => p.id),
      };
    }
    return { team: 'mrwhite', reason, winnerIds: all.filter((p) => p.role === ROLE.MRWHITE && p.alive).map((p) => p.id) };
  }

  function evaluate(state, rng) {
    const w = checkWin(state);
    if (w) { state.winner = w; state.phase = 'result'; return state; }
    state.round++;
    return beginRound(state, rng);
  }

  UU.Engine = {
    MIN_PLAYERS, MAX_PLAYERS, ROLE, WIN_RULES, TIE_RULES,
    maxImpostors, recommend, validateCounts, resolveCounts, isGuessCorrect,
    alive, counts, startGame, finishRoleReveal, beginRound, nextSpeaker,
    startVoting, backToDescribe, currentVoter, optionsFor, castVote, finishVote, continueFromTally,
    quickEliminate, afterReveal, submitGuess, afterGuess, checkWin,
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = UU;
})(typeof window !== 'undefined' ? window : globalThis);
