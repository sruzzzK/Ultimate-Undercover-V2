/* Home screen, Settings screen, "How to play" and the shared rules panel. */
(function (root) {
  'use strict';
  const UU = root.UU;
  const ui = UU.ui;
  const { h } = ui;
  const E = UU.Engine;

  /* ---------- How to play ---------- */
  ui.showHowTo = function () {
    const li = (t, d) => h('p', null, h('b', null, t + ' '), d);
    ui.modal({
      title: 'How to play',
      body: [
        li('Roles.', 'Most players are Civilians and share one secret word. Undercovers get a similar but different word. Mr. White gets no word at all.'),
        li('Pass the phone.', 'Each player privately taps to see their role and word, then hides it and passes the phone on.'),
        li('Describe.', 'In turn, everyone says one short clue about their word — without saying the word itself. Listen carefully for clues that do not fit!'),
        li('Vote.', 'Everyone secretly votes for who they think is an impostor. The player with the most votes is out and their role is revealed.'),
        li('Mr. White.', 'If Mr. White is voted out, they get one guess at the Civilians\' word. A correct guess wins the game on the spot.'),
        li('Winning.', 'Civilians win by removing every Undercover and Mr. White. Impostors win by surviving — the exact rule is set in Settings.'),
      ],
      actions: [{ label: 'Got it', kind: 'primary' }],
    });
  };

  /* ---------- HOME ---------- */
  ui.screens.home = function () {
    const ov = UU.WordBank.overall();
    const used = UU.history.size();
    const resumable = ui.game && ui.game.phase !== 'result';
    return ui.screenEl({ center: true },
      h('div', { class: 'logo-wrap', html: UU.Icons.logo(128) }),
      h('div', null,
        h('h1', { class: 'brand' }, 'Ultimate', h('br'), h('span', { class: 'grad' }, 'Undercover')),
        h('p', { class: 'tagline' }, 'Blend in. Bluff. Find the impostors.')),
      h('div', { class: 'stats' },
        statBox(ui.fmt(ov.pairs), 'Word pairs'),
        statBox(String(ov.categories), 'Categories'),
        statBox(ui.fmt(ov.words), 'Unique words')),
      h('p', { class: 'muted small' },
        used === 0
          ? 'Every pair is still fresh — nothing has been played yet.'
          : ui.fmt(used) + ' pairs played so far · ' + ui.fmt(ov.pairs - used) + ' still fresh'),
      h('div', { class: 'stack' },
        resumable ? ui.btn('Resume game', { kind: 'good', size: 'lg', block: true, icon: 'play', onClick: () => ui.sync() }) : null,
        ui.btn('Play', { kind: 'primary', size: 'lg', block: true, icon: 'play', pulse: !resumable, onClick: () => ui.go('setup') }),
        h('div', { class: 'grid g2' },
          ui.btn('Settings', { icon: 'sliders', onClick: () => ui.go('settings', { from: 'home' }) }),
          ui.btn('How to play', { icon: 'info', onClick: ui.showHowTo }))));
  };
  function statBox(value, label) {
    return h('div', { class: 'card stat' }, h('b', null, value), h('span', null, label));
  }

  /* ---------- shared rules panel (used in Settings and Setup) ---------- */
  ui.rulesPanel = function (rerender) {
    const S = ui.S;
    const set = (k, v) => { S[k] = v; ui.saveSettings(); rerender(); };
    const optList = (table, key) =>
      h('div', { class: 'opt-list' }, Object.keys(table).map((k) =>
        h('button', { type: 'button', class: 'opt' + (S[key] === k ? ' on' : ''), onclick: () => { UU.Sound.play('tap'); set(key, k); } },
          h('b', null, table[k].name), h('span', null, table[k].text))));
    const timerChips = (key) =>
      h('div', { class: 'chips' }, UU.Settings.TIMER_CHOICES.map((n) =>
        h('button', { type: 'button', class: 'chip' + (S[key] === n ? ' on' : ''), onclick: () => { UU.Sound.play('tap'); set(key, n); } }, n === 0 ? 'Off' : n + 's')));
    return h('div', { class: 'stack' },
      h('div', { class: 'stack' }, h('div', { class: 'eyebrow' }, 'Impostor win rule'), optList(E.WIN_RULES, 'winRule'),
        h('p', { class: 'muted small' }, 'Civilians always win by removing every Undercover and Mr. White. Mr. White also wins instantly with a correct guess.')),
      h('div', { class: 'stack' }, h('div', { class: 'eyebrow' }, 'When the vote is tied'), optList(E.TIE_RULES, 'tieRule')),
      h('div', { class: 'stack' }, h('div', { class: 'eyebrow' }, 'Role reveal'),
        ui.toggle('Tell players their role', S.showRoles
          ? 'On: every player sees "Civilian" or "Undercover" along with their word.'
          : 'Off (classic): Civilians and Undercovers only see a word, so an Undercover does not know they are one. Mr. White always sees his role.', S.showRoles,
        (v) => set('showRoles', v))),
      h('div', { class: 'stack' }, h('div', { class: 'eyebrow' }, 'Voting style'),
        ui.seg([{ value: 'secret', label: 'Secret ballots' }, { value: 'quick', label: 'Group decides' }], S.votingMode, (v) => set('votingMode', v)),
        h('p', { class: 'muted small' }, S.votingMode === 'secret'
          ? 'Each player votes privately in turn; counts appear once everyone has voted.'
          : 'Discuss out loud, then one person taps the player the group voted out.')),
      h('div', { class: 'stack' }, h('div', { class: 'eyebrow' }, 'Description timer (per player)'), timerChips('descSeconds')),
      h('div', { class: 'stack' }, h('div', { class: 'eyebrow' }, 'Voting timer (per ballot)'), timerChips('voteSeconds')));
  };

  /* ---------- SETTINGS ---------- */
  ui.screens.settings = function () {
    const S = ui.S;
    const WB = UU.WordBank;
    const back = () => ui.go(ui.params.from === 'setup' ? 'setup' : 'home');
    const apply = () => { ui.saveSettings(); ui.applyTheme(); ui.refresh(); };
    const used = UU.history.size();
    const ov = WB.overall();
    return ui.screenEl({},
      ui.topbar('Settings', { back }),
      ui.card('Look & feel', null, 'sliders',
        h('div', { class: 'stack' },
          h('div', { class: 'eyebrow' }, 'Theme'),
          ui.seg([{ value: 'dark', label: 'Dark' }, { value: 'light', label: 'Light' }, { value: 'auto', label: 'Auto' }], S.theme, (v) => { S.theme = v; apply(); }),
          ui.toggle('Animations', 'Moving background, transitions and confetti', S.animations, (v) => { S.animations = v; apply(); }),
          ui.toggle('Sound effects', 'Short synthesised sounds for taps, reveals and timers', S.sound, (v) => { S.sound = v; apply(); UU.Sound.unlock(); UU.Sound.play('reveal'); }))),
      ui.card('Game rules', 'These apply to every game you start.', 'users', ui.rulesPanel(ui.refresh)),
      ui.card('Word history', 'The game remembers which pairs you played so you do not see them again until the pool runs dry.', 'refresh',
        h('div', { class: 'stack' },
          h('div', { class: 'notice' }, h('b', null, ui.fmt(used)), ' of ', h('b', null, ui.fmt(ov.pairs)), ' pairs played · ', h('b', null, ui.fmt(ov.pairs - used)), ' fresh'),
          ui.toggle('Allow used pairs to return', S.allowRecycle
            ? 'When every pair in your selection has been played, the history for that selection restarts automatically.'
            : 'Off: once a selection is used up you must reset history or pick other categories.', S.allowRecycle,
          (v) => { S.allowRecycle = v; ui.saveSettings(); ui.refresh(); }),
          ui.btn('Reset word history', {
            kind: 'danger', icon: 'trash', disabled: used === 0,
            onClick: () => ui.modal({
              title: 'Reset word history?',
              body: 'Every pair becomes fresh again. This cannot be undone.',
              actions: [{ label: 'Cancel' }, { label: 'Reset', kind: 'danger', onClick: () => { UU.history.reset(); ui.toast('Word history cleared'); ui.refresh(); } }],
            }),
          }))),
      ui.card('About', null, 'info',
        h('div', { class: 'stack' },
          h('p', { class: 'muted small' }, 'Ultimate Undercover · ' + ui.fmt(ov.pairs) + ' word pairs · works offline once loaded.'),
          h('p', { class: 'muted small' }, UU.storage.persistent
            ? 'Settings and history are saved on this device.'
            : 'Saving is unavailable in this browser mode — settings and history will reset when you close the page.'),
          ui.btn('How to play', { icon: 'info', onClick: ui.showHowTo }))));
  };
})(typeof window !== 'undefined' ? window : globalThis);
