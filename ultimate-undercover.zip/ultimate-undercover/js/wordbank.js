/* Word bank logic: filtering, statistics, fair picking and persistent history.
 * The word DATA lives in js/data/words.js (window.UU_WORDS) and is never mixed with game logic. */
(function (root) {
  'use strict';
  const UU = (root.UU = root.UU || {});
  const { cyrb53, norm } = UU.util;

  /* ---------- persistent history ---------- */
  function createHistory(storage) {
    const KEY = 'uu.history.v1';
    const RECENT = 'uu.recentwords.v1';
    const MAX_RECENT = 160;
    let used = new Set(storage.get(KEY, []));
    let recent = storage.get(RECENT, []);
    function save() {
      storage.set(KEY, Array.from(used));
      storage.set(RECENT, recent);
    }
    return {
      has: (id) => used.has(id),
      add(id) { used.add(id); },
      remove(id) { used.delete(id); },
      size: () => used.size,
      /* forget ids that no longer exist in the shipped database */
      prune(validIds) {
        let changed = false;
        for (const id of Array.from(used)) if (!validIds.has(id)) { used.delete(id); changed = true; }
        if (changed) save();
      },
      pushRecent(words) {
        recent = recent.concat(words).slice(-MAX_RECENT);
      },
      recentSet: () => new Set(recent),
      reset() { used = new Set(); recent = []; save(); },
      save,
    };
  }

  /* ---------- word bank ---------- */
  function createWordBank(data) {
    const categories = data.categories;
    const pairs = data.pairs;
    const ids = new Array(pairs.length);
    const idSet = new Set();
    for (let i = 0; i < pairs.length; i++) {
      const key = [norm(pairs[i][0]), norm(pairs[i][1])].sort().join('|');
      ids[i] = cyrb53(key).toString(36);
      idSet.add(ids[i]);
    }
    const catIds = categories.map((c) => c.id);
    const DIFFS = { easy: 0, medium: 1, hard: 2 };
    const poolCache = new Map();

    /* filter = { categories: [id,...] | null (all), difficulty: 'all'|'easy'|'medium'|'hard' } */
    function pool(filter) {
      const f = filter || {};
      const cats = f.categories && f.categories.length ? f.categories.slice().sort() : null;
      const diff = f.difficulty in DIFFS ? DIFFS[f.difficulty] : -1;
      const key = (cats ? cats.join(',') : '*') + '#' + diff;
      if (poolCache.has(key)) return poolCache.get(key);
      const allowed = cats ? new Set(cats.map((id) => catIds.indexOf(id)).filter((i) => i >= 0)) : null;
      const out = [];
      for (let i = 0; i < pairs.length; i++) {
        if (allowed && !allowed.has(pairs[i][2])) continue;
        if (diff >= 0 && pairs[i][3] !== diff) continue;
        out.push(i);
      }
      poolCache.set(key, out);
      return out;
    }

    function stats(filter, history) {
      const p = pool(filter);
      let used = 0;
      for (const i of p) if (history.has(ids[i])) used++;
      return { total: p.length, used, fresh: p.length - used };
    }

    function overall() {
      const words = new Set();
      for (const [a, b] of pairs) { words.add(norm(a)); words.add(norm(b)); }
      return { pairs: pairs.length, categories: categories.length, words: words.size };
    }

    /* Choose one pair.
     * - never repeats a used pair while fresh ones remain
     * - when the pool is exhausted: recycles (if allowed) or reports 'exhausted'
     * - picks a category uniformly first, so small categories are not drowned out
     * - among a handful of random candidates, prefers pairs whose words were not seen recently */
    function pick(filter, opts, history, rng) {
      const allowRecycle = !opts || opts.allowRecycle !== false;
      const p = pool(filter);
      if (!p.length) return { error: 'empty' };
      let fresh = p.filter((i) => !history.has(ids[i]));
      let recycled = false;
      if (!fresh.length) {
        if (!allowRecycle) return { error: 'exhausted' };
        for (const i of p) history.remove(ids[i]);
        fresh = p.slice();
        recycled = true;
      }
      const byCat = new Map();
      for (const i of fresh) {
        const c = pairs[i][2];
        if (!byCat.has(c)) byCat.set(c, []);
        byCat.get(c).push(i);
      }
      const catKeys = Array.from(byCat.keys());
      const list = byCat.get(rng.pick(catKeys));
      const recent = history.recentSet();
      let best = -1;
      let bestScore = Infinity;
      const tries = Math.min(30, list.length);
      const sample = list.length <= 30 ? rng.shuffle(list) : null;
      for (let t = 0; t < tries; t++) {
        const idx = sample ? sample[t] : list[rng.int(list.length)];
        const score = (recent.has(norm(pairs[idx][0])) ? 1 : 0) + (recent.has(norm(pairs[idx][1])) ? 1 : 0);
        if (score < bestScore) { best = idx; bestScore = score; if (score === 0) break; }
      }
      const pair = pairs[best];
      history.add(ids[best]);
      history.pushRecent([norm(pair[0]), norm(pair[1])]);
      history.save();
      return {
        recycled,
        pair: {
          id: ids[best],
          a: pair[0],
          b: pair[1],
          category: categories[pair[2]].name,
          categoryId: categories[pair[2]].id,
          difficulty: data.difficulties[pair[3]],
        },
      };
    }

    return { categories, count: pairs.length, ids, idSet, pool, stats, overall, pick, pairs };
  }

  UU.createHistory = createHistory;
  UU.createWordBank = createWordBank;
  if (root.UU_WORDS) {
    UU.WordBank = createWordBank(root.UU_WORDS);
    UU.history = createHistory(UU.storage);
    UU.history.prune(UU.WordBank.idSet);
  }
  if (typeof module !== 'undefined' && module.exports) module.exports = UU;
})(typeof window !== 'undefined' ? window : globalThis);
