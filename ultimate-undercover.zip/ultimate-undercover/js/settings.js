/* Persistent settings (localStorage) with validation, so a corrupted value can never break the game. */
(function (root) {
  'use strict';
  const UU = (root.UU = root.UU || {});
  const KEY = 'uu.settings.v1';
  const NAMES_KEY = 'uu.players.v1';

  const DEFAULTS = {
    theme: 'dark',            // dark | light | auto
    sound: true,
    animations: true,
    playerCount: 5,
    roleMode: 'auto',         // auto | manual | random
    mrWhiteEnabled: true,
    undercovers: 1,
    mrWhites: 1,
    difficulty: 'all',        // all | easy | medium | hard
    categories: [],           // filled with every category id on first load
    tieRule: 'revote',        // revote | random | none
    winRule: 'parity',        // parity | finalTwo | finalThree
    votingMode: 'secret',     // secret | quick
    descSeconds: 0,           // 0 = no timer
    voteSeconds: 0,
    allowRecycle: true,       // used pairs may return once the pool is exhausted
    showRoles: false,         // false = classic: Civilians/Undercovers only see a word; Mr. White always sees his role
  };
  const ENUMS = {
    theme: ['dark', 'light', 'auto'],
    roleMode: ['auto', 'manual', 'random'],
    difficulty: ['all', 'easy', 'medium', 'hard'],
    tieRule: ['revote', 'random', 'none'],
    winRule: ['parity', 'finalTwo', 'finalThree'],
    votingMode: ['secret', 'quick'],
  };
  const TIMER_CHOICES = [0, 15, 30, 45, 60, 90, 120];

  function clampInt(v, lo, hi, dflt) {
    const n = Math.round(Number(v));
    return Number.isFinite(n) ? Math.min(hi, Math.max(lo, n)) : dflt;
  }

  function sanitize(raw, allCategoryIds) {
    const r = raw && typeof raw === 'object' ? raw : {};
    const s = Object.assign({}, DEFAULTS);
    for (const k of Object.keys(ENUMS)) if (ENUMS[k].includes(r[k])) s[k] = r[k];
    for (const k of ['sound', 'animations', 'mrWhiteEnabled', 'allowRecycle', 'showRoles']) if (typeof r[k] === 'boolean') s[k] = r[k];
    s.playerCount = clampInt(r.playerCount, 3, 20, DEFAULTS.playerCount);
    s.undercovers = clampInt(r.undercovers, 0, 19, DEFAULTS.undercovers);
    s.mrWhites = clampInt(r.mrWhites, 0, 19, DEFAULTS.mrWhites);
    for (const k of ['descSeconds', 'voteSeconds']) s[k] = TIMER_CHOICES.includes(r[k]) ? r[k] : 0;
    const known = new Set(allCategoryIds);
    s.categories = Array.isArray(r.categories) ? r.categories.filter((id) => known.has(id)) : allCategoryIds.slice();
    if (!Array.isArray(r.categories)) s.categories = allCategoryIds.slice();
    return s;
  }

  const Settings = {
    DEFAULTS, TIMER_CHOICES,
    load(allCategoryIds) {
      const s = sanitize(UU.storage.get(KEY, null), allCategoryIds);
      // first launch: respect the OS "reduce motion" preference
      if (UU.storage.get(KEY, null) === null && root.matchMedia) {
        try { if (root.matchMedia('(prefers-reduced-motion: reduce)').matches) s.animations = false; } catch (e) { /* ignore */ }
      }
      return s;
    },
    save(s) { UU.storage.set(KEY, s); },
    loadNames() {
      const n = UU.storage.get(NAMES_KEY, []);
      return Array.isArray(n) ? n.filter((x) => typeof x === 'string').slice(0, 20) : [];
    },
    saveNames(names) { UU.storage.set(NAMES_KEY, names); },
    sanitize,
  };
  UU.Settings = Settings;
  if (typeof module !== 'undefined' && module.exports) module.exports = UU;
})(typeof window !== 'undefined' ? window : globalThis);
