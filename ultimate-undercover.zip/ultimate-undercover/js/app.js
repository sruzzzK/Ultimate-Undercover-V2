/* Boot: load settings, restore an unfinished game, register the offline service worker. */
(function (root) {
  'use strict';
  const UU = root.UU;
  const ui = UU.ui;
  const PHASES = ['roles', 'describe', 'vote', 'tally', 'eliminate', 'guess', 'guessResult'];

  /* Only accept a saved game that is structurally sound; anything else is discarded. */
  function validGame(g) {
    try {
      return g && g.v === 1 && PHASES.includes(g.phase) && Array.isArray(g.players) && g.players.length >= 3 &&
        g.players.every((p) => p && typeof p.name === 'string' && ['civilian', 'undercover', 'mrwhite'].includes(p.role)) &&
        g.words && typeof g.words.civilian === 'string' && g.settings && Array.isArray(g.log);
    } catch (e) { return false; }
  }

  function boot() {
    ui.S = UU.Settings.load(UU.WordBank.categories.map((c) => c.id));
    ui.applyTheme();
    ui.initSetup();

    const saved = UU.storage.get('uu.game.v1', null);
    if (validGame(saved)) ui.game = saved; else if (saved) UU.storage.remove('uu.game.v1');

    ui.go('home');

    // audio can only start after a user gesture on mobile
    root.addEventListener('pointerdown', () => UU.Sound.unlock(), { once: true });
    // never leave a secret on screen when the app is backgrounded
    root.document.addEventListener('visibilitychange', () => { if (root.document.hidden) ui.hideSecrets(); });
    root.addEventListener('pagehide', () => ui.hideSecrets());
    if (root.matchMedia) {
      try {
        root.matchMedia('(prefers-color-scheme: light)').addEventListener('change', () => { if (ui.S.theme === 'auto') ui.applyTheme(); });
      } catch (e) { /* older browsers */ }
    }
    root.addEventListener('error', (e) => { if (root.console) console.error(e.error || e.message); ui.toast('Something went wrong — your game is safe'); });
    root.addEventListener('unhandledrejection', (e) => { if (root.console) console.error(e.reason); });

    if ('serviceWorker' in root.navigator && /^https?:$/.test(root.location.protocol)) {
      root.addEventListener('load', () => root.navigator.serviceWorker.register('sw.js').catch(() => {}));
    }
  }

  if (root.document.readyState === 'loading') root.document.addEventListener('DOMContentLoaded', boot);
  else boot();
})(window);
