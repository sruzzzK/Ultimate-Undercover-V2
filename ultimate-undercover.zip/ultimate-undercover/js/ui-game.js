/* In-game screens: role reveal, description round, voting, tally, elimination, Mr. White's guess. */
(function (root) {
  'use strict';
  const UU = root.UU;
  const ui = UU.ui;
  const { h, ROLE_NAME, ROLE_CLS } = ui;
  const E = UU.Engine;

  const initial = (name) => (name.trim().charAt(0) || '?').toUpperCase();
  const gameBar = (title, eyebrow) => ui.topbar(title, { eyebrow, right: ui.iconBtn('menu', 'Menu', () => ui.gameMenu()) });

  ui.gameMenu = function () {
    const S = ui.S;
    const body = h('div', { class: 'stack' },
      ui.toggle('Sound effects', null, S.sound, (v) => { S.sound = v; ui.saveSettings(); ui.applyTheme(); ui.gameMenu(); }),
      ui.toggle('Animations', null, S.animations, (v) => { S.animations = v; ui.saveSettings(); ui.applyTheme(); ui.gameMenu(); }));
    ui.modal({
      title: 'Game menu', body,
      actions: [
        { label: 'How to play', onClick: () => { setTimeout(ui.showHowTo, 0); } },
        { label: 'Resume', kind: 'primary' },
        { label: 'Quit game', kind: 'danger', onClick: () => { setTimeout(ui.confirmQuit, 0); } },
      ],
    });
  };

  /* Hide anything secret (called when the app goes to the background). */
  ui.hideSecrets = function () {
    if (ui.name === 'roles' && ui.sub.stage === 'reveal') { ui.sub.stage = 'pass'; ui.refresh(); }
    if (ui._modal && ui._modal.querySelector('.reveal-card')) ui.closeModal();
  };

  /* The private card showing a player's word (and role, when allowed). */
  ui.revealCard = function (p, forceRole) {
    const g = ui.game;
    const showRole = !!forceRole || p.role === 'mrwhite' || !!g.settings.showRoles;
    const cls = showRole ? p.role : 'neutral';
    const note = forceRole ? { civilian: 'An ordinary Civilian with the shared word.', undercover: 'Hiding among you with a different word.', mrwhite: 'Had no word at all.' }[p.role]
      : p.role === 'mrwhite' ? 'You have no word. Listen closely, bluff your way through, and if you are voted out you get one guess at the Civilians\' word.'
        : showRole ? (p.role === 'undercover' ? 'Your word differs from the Civilians\'. Blend in!' : 'Find the impostors.') + ' Memorise your word and keep it secret.'
          : 'Memorise your word and keep it secret. Do not say it out loud!';
    return h('div', { class: 'reveal-card ' + cls },
      h('span', { class: 'emblem', html: showRole ? UU.Icons.role[p.role] : UU.Icons.ui.lock }),
      h('div', { class: 'rname' }, showRole ? ROLE_NAME[p.role] : 'Your secret word'),
      h('div', { class: 'word' }, p.word || (p.role === 'mrwhite' ? 'No word' : '—')),
      h('p', { class: 'note' }, note));
  };
  const passCard = (eyebrow, name, text) => h('div', { class: 'pass-card' },
    h('div', { class: 'badge' }, initial(name)),
    h('div', { class: 'eyebrow' }, eyebrow),
    h('div', { class: 'bigname' }, name),
    h('p', { class: 'muted' }, text));

  /* ---------- ROLE DISTRIBUTION ---------- */
  ui.screens.roles = function () {
    const g = ui.game;
    const p = g.players[g.revealIndex];
    const last = g.revealIndex === g.players.length - 1;
    const next = last ? null : g.players[g.revealIndex + 1];
    const stage = ui.sub.stage || 'pass';
    const progress = 'Player ' + (g.revealIndex + 1) + ' of ' + g.players.length;
    if (stage === 'pass') {
      return ui.screenEl({ center: true },
        h('div', { class: 'eyebrow' }, progress),
        passCard('Pass the device to', p.name, 'Make sure nobody else can see the screen, then tap the button.'),
        ui.btn('I am ' + p.name + ' — show my ' + (p.role === 'mrwhite' || g.settings.showRoles ? 'role' : 'word'), {
          kind: 'primary', size: 'lg', block: true, icon: 'eye', sound: 'reveal',
          onClick: () => { ui.sub.stage = 'reveal'; ui.refresh(); },
        }),
        h('p', { class: 'muted small' }, 'Only ' + p.name + ' should look at the next screen.'));
    }
    return ui.screenEl({ center: true },
      h('div', { class: 'eyebrow' }, progress + ' · for ' + p.name + ' only'),
      ui.revealCard(p),
      ui.btn(last ? 'Hide — start the game' : 'Hide and pass to ' + next.name, {
        kind: 'primary', size: 'lg', block: true, icon: 'eyeOff', sound: 'pass',
        onClick: () => { E.finishRoleReveal(g, UU.rng); ui.sync(); },
      }));
  };

  /* ---------- DESCRIPTION ROUND ---------- */
  function hudPills(g) {
    const k = E.counts(g);
    const pills = [h('span', { class: 'pill' }, ui.icon('users'), k.total + ' left')];
    if (g.settings.roleMode === 'random') pills.push(h('span', { class: 'pill' }, 'Impostors: ?'));
    else {
      pills.push(h('span', { class: 'pill c-und' }, k.undercover + ' Undercover'));
      if (g.startCounts.mrWhites > 0) pills.push(h('span', { class: 'pill c-mrw' }, k.mrwhite + ' Mr. White'));
    }
    return h('div', { class: 'hud' }, pills);
  }

  ui.screens.describe = function () {
    const g = ui.game;
    const d = g.describe;
    const done = d.index >= d.order.length;
    const cur = done ? null : g.players[d.order[d.index]];
    const seconds = g.settings.descSeconds;
    const last = d.index === d.order.length - 1;

    const speaker = h('div', { class: 'card speaker' },
      done
        ? [h('div', { class: 'eyebrow' }, 'Round ' + g.round), h('div', { class: 'now grad' }, 'Everyone has spoken'),
          h('p', { class: 'muted' }, 'Discuss who sounded suspicious, then head to the vote.')]
        : [h('div', { class: 'eyebrow' }, 'Now describing · ' + (d.index + 1) + ' of ' + d.order.length), h('div', { class: 'now' }, cur.name),
          h('p', { class: 'muted' }, 'Give one short clue about your word — without saying it.'),
          seconds > 0 ? h('div', { style: { margin: '12px 0 4px' } }, ui.timerRing(seconds, null)) : null,
          ui.btn(last ? 'Finish round' : 'Next speaker', { kind: 'primary', block: true, icon: 'chevron', onClick: () => { E.nextSpeaker(g); ui.saveGame(); ui.refresh(); } })]);

    const order = h('div', { class: 'order' }, d.order.map((id, i) =>
      h('div', { class: 'it' + (i === d.index ? ' cur' : '') + (i < d.index ? ' done' : '') },
        h('span', { class: 'n' }, i < d.index ? '✓' : String(i + 1)), h('b', null, g.players[id].name),
        i === d.index ? h('span', { class: 'tag' }, 'speaking') : null)));

    return ui.screenEl({},
      gameBar('Round ' + g.round, 'Description'),
      hudPills(g), speaker,
      ui.card('Speaking order', null, null, order),
      ui.dock(false,
        ui.btn('Check my word', { icon: 'lock', onClick: () => peekPick() }),
        ui.btn(done ? 'Start voting' : 'Go to voting', { kind: done ? 'primary' : '', icon: 'chevron', onClick: () => { E.startVoting(g); ui.sync(); } })));
  };

  /* "Check my word": a player re-reads their own word without anyone else seeing it. */
  function peekPick() {
    const g = ui.game;
    const list = h('div', { class: 'grid g2' }, E.alive(g).map((p) =>
      ui.btn(p.name, { onClick: () => { setTimeout(() => peekPass(p), 0); } })));
    ui.modal({ title: 'Who needs to check?', body: [h('p', null, 'Pick your name, then you will get the device privately.'), list], actions: [{ label: 'Cancel' }] });
  }
  function peekPass(p) {
    ui.modal({
      title: 'Pass the device to ' + p.name, body: 'Make sure nobody else is looking, then tap show.',
      actions: [{ label: 'Cancel' }, { label: 'Show my word', kind: 'primary', sound: 'reveal', onClick: () => { setTimeout(() => peekShow(p), 0); } }],
    });
  }
  function peekShow(p) {
    ui.modal({ title: null, body: ui.revealCard(p), actions: [{ label: 'Hide', kind: 'primary', sound: 'pass' }], dismiss: false });
  }

  /* ---------- VOTING ---------- */
  ui.screens.vote = function () {
    const g = ui.game;
    return g.settings.votingMode === 'quick' ? quickVote(g) : secretVote(g);
  };

  function quickVote(g) {
    const sel = ui.sub.sel;
    const seconds = g.settings.voteSeconds;
    return ui.screenEl({},
      gameBar('Vote', 'Round ' + g.round),
      hudPills(g),
      ui.card('Discuss, then decide', 'Talk it through, vote out loud, and tap the player the group chose.', 'users',
        seconds > 0 ? h('div', { style: { margin: '4px 0 14px' } }, ui.timerRing(seconds, null)) : null,
        h('div', { class: 'vote-grid' }, E.alive(g).map((p) =>
          h('button', { type: 'button', class: 'vote-btn' + (sel === p.id ? ' sel' : ''), 'aria-pressed': String(sel === p.id), onclick: () => { UU.Sound.play('tap'); ui.sub.sel = p.id; ui.refresh(); } }, p.name)))),
      ui.dock(false,
        ui.btn('Back to talking', { onClick: () => { E.backToDescribe(g); ui.sync(); } }),
        ui.btn(sel == null ? 'Pick a player' : 'Vote out ' + g.players[sel].name, {
          kind: 'danger', disabled: sel == null, icon: 'check',
          onClick: () => ui.modal({
            title: 'Vote out ' + g.players[sel].name + '?', body: 'Their role will be revealed next.',
            actions: [{ label: 'Cancel' }, { label: 'Confirm', kind: 'danger', sound: 'out', onClick: () => { E.quickEliminate(g, sel, UU.rng); ui.sync(); } }],
          }),
        })));
  }

  function secretVote(g) {
    const v = g.vote;
    const voter = g.players[E.currentVoter(g)];
    const stage = ui.sub.stage || 'pass';
    const revote = v.attempt > 0;
    const tieNames = revote ? v.candidates.map((id) => g.players[id].name).join(' & ') : '';
    const progress = 'Ballot ' + (v.index + 1) + ' of ' + v.voters.length;
    if (stage === 'pass') {
      return ui.screenEl({ center: true },
        h('div', { class: 'eyebrow' }, (revote ? 'Tie-break vote · ' : 'Secret vote · ') + progress),
        revote ? h('div', { class: 'notice warn' }, 'Tie between ' + tieNames + '. Only they are on this ballot.') : null,
        passCard('Pass the device to', voter.name, 'Vote privately. Nobody will see who you picked.'),
        ui.btn('I am ' + voter.name + ' — vote', { kind: 'primary', size: 'lg', block: true, icon: 'check', onClick: () => { ui.sub.stage = 'ballot'; ui.refresh(); } }),
        ui.btn('Menu', { size: 'sm', onClick: () => ui.gameMenu() }));
    }
    const options = E.optionsFor(g, voter.id);
    const sel = ui.sub.sel;
    const seconds = g.settings.voteSeconds;
    return ui.screenEl({},
      ui.topbar(voter.name + ', who is the impostor?', { eyebrow: (revote ? 'Tie-break · ' : '') + progress }),
      seconds > 0 ? ui.timerRing(seconds, null) : null,
      h('div', { class: 'vote-grid' }, options.map((id) =>
        h('button', { type: 'button', class: 'vote-btn' + (sel === id ? ' sel' : ''), 'aria-pressed': String(sel === id), onclick: () => { UU.Sound.play('tap'); ui.sub.sel = id; ui.refresh(); } }, g.players[id].name))),
      h('p', { class: 'muted small center-text' }, 'You cannot vote for yourself.'),
      ui.dock(false, ui.btn(sel == null ? 'Choose someone' : 'Confirm vote for ' + g.players[sel].name, {
        kind: 'primary', size: 'lg', disabled: sel == null, icon: 'lock', sound: 'vote',
        onClick: () => {
          const finished = E.castVote(g, voter.id, sel);
          if (finished) E.finishVote(g, UU.rng);
          ui.sync();
        },
      })));
  }

  /* ---------- TALLY ---------- */
  ui.screens.tally = function () {
    const g = ui.game;
    const t = g.tally;
    const name = (id) => g.players[id].name;
    const maxV = Math.max(1, t.rows[0].votes);
    const bars = [];
    const rows = h('div', { class: 'tally' }, t.rows.map((r) => {
      const bar = h('i');
      bars.push([bar, Math.round((r.votes / maxV) * 100)]);
      return h('div', { class: 'tr' + (t.leaders.includes(r.id) ? ' top' : '') },
        h('b', null, name(r.id)), h('span', { class: 'cnt' }, ui.plural(r.votes, 'vote')), h('div', { class: 'bar' }, bar));
    }));
    requestAnimationFrame(() => requestAnimationFrame(() => bars.forEach(([b, pct]) => { b.style.width = Math.max(pct, 3) + '%'; })));
    const lead = t.leaders.map(name).join(' & ');
    let headline;
    let text;
    if (t.action === 'eliminate') { headline = name(t.eliminatedId) + ' is out!'; text = 'They received the most votes.'; }
    else if (t.action === 'revote') { headline = 'It is a tie!'; text = lead + ' tied. Only they stay on the ballot for a re-vote.'; }
    else if (t.action === 'random') { headline = name(t.eliminatedId) + ' is out!'; text = lead + ' were tied, so fate chose one.'; }
    else { headline = 'It is a tie!'; text = lead + ' tied. Nobody leaves — describe again and vote once more.'; }
    return ui.screenEl({},
      gameBar('Votes are in', 'Round ' + g.round),
      h('div', { class: 'card speaker' }, h('div', { class: 'now grad' }, headline), h('p', { class: 'muted' }, text)),
      ui.card('Result', 'Only totals are shown — individual ballots stay secret.', 'users', rows),
      ui.dock(false, ui.btn(t.action === 'revote' ? 'Start the re-vote' : t.action === 'none' ? 'Next round' : 'Reveal their role', {
        kind: 'primary', size: 'lg', icon: 'chevron', sound: t.action === 'eliminate' || t.action === 'random' ? 'out' : 'tap',
        onClick: () => { E.continueFromTally(g, UU.rng); ui.sync(); },
      })));
  };

  /* ---------- ELIMINATION ---------- */
  ui.screens.eliminate = function () {
    const g = ui.game;
    const el = g.elimination;
    const p = g.players[el.id];
    const revealed = !!ui.sub.revealed;
    if (!revealed) {
      return ui.screenEl({ center: true },
        h('div', { class: 'eyebrow' }, 'Voted out'),
        h('h1', { class: 'brand', style: { fontSize: '2.4rem' } }, p.name),
        h('button', { type: 'button', class: 'mystery', 'aria-label': 'Reveal role', onclick: () => { UU.Sound.play(p.role === 'civilian' ? 'lose' : 'reveal'); ui.sub.revealed = true; ui.refresh(); } }, '?'),
        h('p', { class: 'muted' }, 'Tap the card to reveal their role.'));
    }
    const mw = p.role === 'mrwhite';
    return ui.screenEl({ center: true },
      h('div', { class: 'eyebrow' }, p.name + ' was...'),
      ui.revealCard(p, true),
      p.role === 'civilian' ? h('div', { class: 'notice err' }, 'An innocent Civilian was eliminated!') : h('div', { class: 'notice ok' }, 'Good catch — an impostor is out.'),
      ui.btn(mw ? 'Mr. White\'s last guess' : 'Continue', {
        kind: 'primary', size: 'lg', block: true, icon: 'chevron',
        onClick: () => { E.afterReveal(g, UU.rng); ui.sync(); },
      }));
  };

  /* ---------- MR. WHITE'S GUESS ---------- */
  ui.screens.guess = function () {
    const g = ui.game;
    const el = g.elimination;
    const p = g.players[el.id];
    if (g.phase === 'guessResult') {
      const ok = el.guess.correct;
      return ui.screenEl({ center: true },
        h('div', { class: 'eyebrow' }, p.name + ' guessed'),
        h('div', { class: 'card speaker' },
          h('div', { class: 'now ' + (ok ? 'grad' : '') }, ok ? 'Correct!' : 'Not quite'),
          h('p', { class: 'bigname', style: { fontSize: '1.6rem', fontWeight: '900', margin: '8px 0' } }, el.guess.text ? '"' + el.guess.text + '"' : 'No guess'),
          h('p', { class: 'muted' }, ok ? 'Mr. White found the Civilians\' word and wins!' : 'That is not the Civilians\' word. The game goes on.')),
        ui.btn(ok ? 'See the results' : 'Continue', { kind: ok ? 'good' : 'primary', size: 'lg', block: true, icon: 'chevron', sound: ok ? 'win' : 'tap', onClick: () => { E.afterGuess(g, UU.rng); ui.sync(); } }));
    }
    const input = h('input', {
      class: 'field', type: 'text', maxlength: '40', autocomplete: 'off', autocapitalize: 'words', spellcheck: 'false',
      placeholder: 'Type the Civilians\' word', 'aria-label': 'Your guess', style: { fontSize: '1.3rem', textAlign: 'center', minHeight: '58px' },
      onkeydown: (e) => { if (e.key === 'Enter') submit(); },
    });
    function submit() {
      const text = input.value.trim();
      if (!text) { UU.Sound.play('error'); ui.toast('Type a guess first, or tap "I have no idea"'); return; }
      E.submitGuess(g, text);
      ui.sync();
    }
    setTimeout(() => { try { input.focus(); } catch (e) { /* ignore */ } }, 350);
    return ui.screenEl({ center: true },
      h('div', { class: 'eyebrow' }, 'Mr. White\'s last chance'),
      h('div', { class: 'pass-card' },
        h('span', { class: 'emblem c-mrw', style: { display: 'block', width: '80px', height: '80px', margin: '0 auto' }, html: UU.Icons.role.mrwhite }),
        h('div', { class: 'bigname' }, p.name),
        h('p', { class: 'muted' }, 'You have one guess. What word do the Civilians have? Get it right and you win instantly.')),
      input,
      ui.btn('Submit guess', { kind: 'primary', size: 'lg', block: true, icon: 'check', onClick: submit }),
      ui.btn('I have no idea', { block: true, onClick: () => { E.submitGuess(g, ''); ui.sync(); } }));
  };
})(typeof window !== 'undefined' ? window : globalThis);
