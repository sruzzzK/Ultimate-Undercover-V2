/* Sound effects synthesised with the Web Audio API — no audio files, works offline. */
(function (root) {
  'use strict';
  const UU = (root.UU = root.UU || {});
  let ctx = null;
  let enabled = true;

  function ensure() {
    if (ctx) return ctx;
    const AC = root.AudioContext || root.webkitAudioContext;
    if (!AC) return null;
    try { ctx = new AC(); } catch (e) { ctx = null; }
    return ctx;
  }

  function tone(freq, start, dur, type, volume) {
    const c = ctx;
    const t0 = c.currentTime + start;
    const osc = c.createOscillator();
    const gain = c.createGain();
    osc.type = type || 'sine';
    osc.frequency.setValueAtTime(freq, t0);
    gain.gain.setValueAtTime(0.0001, t0);
    gain.gain.exponentialRampToValueAtTime(Math.max(0.0002, volume || 0.12), t0 + 0.012);
    gain.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    osc.connect(gain);
    gain.connect(c.destination);
    osc.start(t0);
    osc.stop(t0 + dur + 0.05);
  }

  const PATTERNS = {
    tap: [[620, 0, 0.07, 'triangle', 0.08]],
    pass: [[330, 0, 0.09, 'sine', 0.1], [440, 0.08, 0.12, 'sine', 0.1]],
    reveal: [[392, 0, 0.12, 'triangle', 0.12], [523, 0.1, 0.12, 'triangle', 0.12], [784, 0.2, 0.28, 'triangle', 0.12]],
    vote: [[260, 0, 0.1, 'square', 0.05], [390, 0.09, 0.14, 'square', 0.05]],
    tick: [[900, 0, 0.04, 'square', 0.04]],
    alarm: [[880, 0, 0.16, 'sawtooth', 0.07], [660, 0.2, 0.16, 'sawtooth', 0.07], [880, 0.4, 0.22, 'sawtooth', 0.07]],
    out: [[440, 0, 0.18, 'sawtooth', 0.08], [330, 0.16, 0.18, 'sawtooth', 0.08], [220, 0.32, 0.36, 'sawtooth', 0.08]],
    win: [[523, 0, 0.14, 'triangle', 0.13], [659, 0.12, 0.14, 'triangle', 0.13], [784, 0.24, 0.14, 'triangle', 0.13], [1046, 0.36, 0.5, 'triangle', 0.14]],
    lose: [[392, 0, 0.2, 'sine', 0.12], [349, 0.2, 0.2, 'sine', 0.12], [294, 0.4, 0.45, 'sine', 0.12]],
    error: [[200, 0, 0.14, 'square', 0.06], [160, 0.12, 0.18, 'square', 0.06]],
  };

  UU.Sound = {
    setEnabled(v) { enabled = !!v; },
    /* must be called from a user gesture at least once to unlock audio on mobile browsers */
    unlock() { const c = ensure(); if (c && c.state === 'suspended') c.resume().catch(() => {}); },
    play(name) {
      if (!enabled) return;
      const c = ensure();
      if (!c) return;
      if (c.state === 'suspended') c.resume().catch(() => {});
      const p = PATTERNS[name];
      if (!p) return;
      try { p.forEach((a) => tone(a[0], a[1], a[2], a[3], a[4])); } catch (e) { /* audio is optional */ }
    },
  };
})(typeof window !== 'undefined' ? window : globalThis);
