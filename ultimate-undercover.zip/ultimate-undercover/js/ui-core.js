/* UI core: DOM helper, router, modal/toast, shared components, timer ring, confetti, theming. */
(function (root) {
  'use strict';
  const UU = (root.UU = root.UU || {});
  const doc = root.document;

  /* ---------- tiny DOM helper (text is always inserted as text nodes — names can never inject HTML) ---------- */
  function append(el, c) {
    if (c == null || c === false) return;
    if (Array.isArray(c)) { c.forEach((x) => append(el, x)); return; }
    el.appendChild(c.nodeType ? c : doc.createTextNode(String(c)));
  }
  function h(tag, props) {
    const el = doc.createElement(tag);
    if (props) {
      for (const k in props) {
        const v = props[k];
        if (v == null || v === false) continue;
        if (k === 'class') el.className = v;
        else if (k === 'html') el.innerHTML = v; // only ever fed with our own SVG strings
        else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
        else if (k.slice(0, 2) === 'on' && typeof v === 'function') el.addEventListener(k.slice(2), v);
        else if (k === 'value' || k === 'checked' || k === 'disabled') el[k] = v;
        else el.setAttribute(k, v === true ? '' : v);
      }
    }
    for (let i = 2; i < arguments.length; i++) append(el, arguments[i]);
    return el;
  }

  const ROLE_NAME = { civilian: 'Civilian', undercover: 'Undercover', mrwhite: 'Mr. White' };
  const ROLE_CLS = { civilian: 'civ', undercover: 'und', mrwhite: 'mrw' };

  const ui = (UU.ui = {
    h, ROLE_NAME, ROLE_CLS,
    screens: {}, name: 'home', params: {}, sub: {},
    S: null, game: null, setup: null, lastRun: null,
    timers: [], _trap: false, _modal: null,
  });

  const $ = (sel) => doc.querySelector(sel);
  ui.icon = (name, cls) => UU.Icons.html(UU.Icons.ui[name], cls);
  ui.emblem = (role, cls) => h('span', { class: 'emblem ' + (cls || ''), html: UU.Icons.role[role] });
  ui.plural = (n, one, many) => n + ' ' + (n === 1 ? one : many || one + 's');
  ui.fmt = (n) => Number(n).toLocaleString('en-US');

  /* ---------- theme / persistence ---------- */
  ui.applyTheme = function () {
    const S = ui.S;
    let t = S.theme;
    if (t === 'auto') {
      t = root.matchMedia && root.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark';
    }
    doc.documentElement.setAttribute('data-theme', t);
    const meta = doc.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', t === 'light' ? '#f1f2ff' : '#090c1e');
    doc.body.classList.toggle('no-anim', !S.animations);
    UU.Sound.setEnabled(S.sound);
  };
  ui.saveSettings = function () { UU.Settings.save(ui.S); };
  ui.saveGame = function () {
    if (ui.game && ui.game.phase !== 'result') UU.storage.set('uu.game.v1', ui.game);
    else UU.storage.remove('uu.game.v1');
  };

  /* ---------- router ---------- */
  ui.draw = function (animate) {
    ui.stopTimer();
    ui.stopConfetti();
    const y = root.scrollY;
    let node;
    try {
      node = ui.screens[ui.name]();
    } catch (e) {
      if (root.console) console.error(e);
      node = ui.errorScreen(e);
    }
    if (animate && ui.S.animations) node.classList.add('enter');
    const app = $('#app');
    app.textContent = '';
    app.appendChild(node);
    root.scrollTo(0, animate ? 0 : y);
  };
  ui.refresh = function () { ui.draw(false); };
  ui.go = function (name, params) {
    ui.name = name;
    ui.params = params || {};
    ui.sub = {};
    ui.draw(true);
    if (name !== 'home' && !ui._trap) {
      try { root.history.pushState({ uu: 1 }, ''); ui._trap = true; } catch (e) { /* ignore */ }
    }
  };
  ui.errorScreen = function (e) {
    return h('div', { class: 'screen center' },
      h('h1', null, 'Something went wrong'),
      h('p', { class: 'muted' }, String(e && e.message ? e.message : e)),
      ui.btn('Back to home', { kind: 'primary', block: true, onClick: () => { ui.go('home'); } }));
  };

  /* game phase -> screen */
  const PHASE_SCREEN = { roles: 'roles', describe: 'describe', vote: 'vote', tally: 'tally', eliminate: 'eliminate', guess: 'guess', guessResult: 'guess', result: 'result' };
  ui.sync = function () {
    ui.saveGame();
    ui.go(PHASE_SCREEN[ui.game.phase]);
  };
  ui.inGame = () => !!ui.game && ['roles', 'describe', 'vote', 'tally', 'eliminate', 'guess', 'result'].includes(ui.name);

  /* ---------- Android / browser back button ---------- */
  ui.onBack = function () {
    if (ui._modal) { ui.closeModal(); return; }
    if (ui.name === 'home') return;
    if (ui.name === 'setup' || ui.name === 'settings') { ui.go('home'); return; }
    if (ui.name === 'result') { ui.go('home'); return; }
    ui.confirmQuit();
  };
  root.addEventListener('popstate', function () {
    ui._trap = false;
    if (ui.name === 'home' && !ui._modal) return; // let the next "back" leave the app
    ui.onBack();
    if (ui.name !== 'home' && !ui._trap) {
      try { root.history.pushState({ uu: 1 }, ''); ui._trap = true; } catch (e) { /* ignore */ }
    }
  });

  ui.confirmQuit = function () {
    ui.modal({
      title: 'Leave this game?',
      body: 'The current round will be lost. Word history keeps the pair you were given, so it will not come back soon.',
      actions: [
        { label: 'Keep playing', kind: 'primary' },
        { label: 'Quit to home', kind: 'danger', onClick: () => { ui.game = null; ui.saveGame(); ui.go('home'); } },
      ],
    });
  };

  /* ---------- components ---------- */
  ui.btn = function (label, o) {
    o = o || {};
    const cls = ['btn', o.kind || '', o.size || '', o.block ? 'block' : '', o.pulse ? 'pulse' : ''].filter(Boolean).join(' ');
    return h('button', {
      class: cls, type: 'button', disabled: !!o.disabled, title: o.title,
      onclick: function (e) {
        UU.Sound.unlock();
        UU.Sound.play(o.sound || 'tap');
        if (o.onClick) o.onClick(e);
      },
    }, o.icon ? ui.icon(o.icon) : null, label);
  };
  ui.iconBtn = function (icon, label, fn) {
    return h('button', { class: 'icon-btn', type: 'button', 'aria-label': label, title: label, onclick: () => { UU.Sound.play('tap'); fn(); } }, ui.icon(icon));
  };
  ui.seg = function (options, value, onChange) {
    return h('div', { class: 'seg', role: 'group' }, options.map((o) =>
      h('button', {
        type: 'button', class: o.value === value ? 'on' : '', 'aria-pressed': String(o.value === value),
        onclick: () => { UU.Sound.play('tap'); onChange(o.value); },
      }, o.label)));
  };
  ui.toggle = function (label, desc, value, onChange) {
    return h('div', {
      class: 'toggle-row', role: 'switch', tabindex: '0', 'aria-checked': String(!!value),
      onclick: () => { UU.Sound.play('tap'); onChange(!value); },
      onkeydown: (e) => { if (e.key === ' ' || e.key === 'Enter') { e.preventDefault(); onChange(!value); } },
    }, h('div', { class: 'txt' }, h('b', null, label), desc ? h('span', { class: 'd' }, desc) : null),
      h('div', { class: 'switch' + (value ? ' on' : '') }));
  };
  ui.stepper = function (value, min, max, onChange, label) {
    return h('div', { class: 'stepper', role: 'group', 'aria-label': label || 'value' },
      h('button', { type: 'button', 'aria-label': 'decrease', disabled: value <= min, onclick: () => { UU.Sound.play('tap'); onChange(value - 1); } }, ui.icon('minus')),
      h('output', null, String(value)),
      h('button', { type: 'button', 'aria-label': 'increase', disabled: value >= max, onclick: () => { UU.Sound.play('tap'); onChange(value + 1); } }, ui.icon('plus')));
  };
  ui.screenEl = function (opts) {
    const o = opts || {};
    const kids = Array.prototype.slice.call(arguments, 1);
    return h('div', { class: 'screen' + (o.center ? ' center' : '') + (o.wide ? ' wide' : '') }, kids);
  };
  ui.topbar = function (title, o) {
    o = o || {};
    return h('div', { class: 'topbar' },
      o.back ? ui.iconBtn('back', 'Back', o.back) : null,
      h('div', { class: 'grow' }, o.eyebrow ? h('div', { class: 'eyebrow' }, o.eyebrow) : null, h('h1', null, title)),
      o.right || null);
  };
  ui.dock = function (wide) {
    const kids = Array.prototype.slice.call(arguments, 1);
    return h('div', { class: 'dock' + (wide ? ' wide' : '') }, h('div', null, kids));
  };
  ui.card = function (title, hint, icon) {
    const kids = Array.prototype.slice.call(arguments, 3);
    return h('section', { class: 'card' },
      title ? h('h2', null, icon ? ui.icon(icon) : null, title) : null,
      hint ? h('p', { class: 'hint' }, hint) : null, kids);
  };

  /* ---------- modal & toast ---------- */
  ui.closeModal = function () {
    const ov = $('#overlay');
    if (ui._modalCleanup) { try { ui._modalCleanup(); } catch (e) { /* ignore */ } ui._modalCleanup = null; }
    ov.textContent = '';
    ui._modal = null;
  };
  /* opts: { title, body (node|string|array), actions:[{label, kind, onClick}], dismiss, onClose } */
  ui.modal = function (opts) {
    ui.closeModal();
    const body = typeof opts.body === 'string' ? h('p', null, opts.body) : opts.body;
    const acts = (opts.actions || []).map((a) => ui.btn(a.label, {
      kind: a.kind, sound: a.sound,
      onClick: () => { if (a.onClick && a.onClick() === false) return; ui.closeModal(); },
    }));
    const box = h('div', { class: 'modal', role: 'dialog', 'aria-modal': 'true' },
      opts.title ? h('h2', null, opts.title) : null,
      h('div', { class: 'body' }, body),
      acts.length ? h('div', { class: 'acts' }, acts) : null);
    const back = h('div', { class: 'backdrop', onclick: (e) => { if (e.target === back && opts.dismiss !== false) ui.closeModal(); } }, box);
    $('#overlay').appendChild(back);
    ui._modal = back;
    ui._modalCleanup = opts.onClose || null;
    return { close: ui.closeModal, box };
  };
  let toastTimer = null;
  ui.toast = function (msg) {
    const old = doc.querySelector('.toast');
    if (old) old.remove();
    const t = h('div', { class: 'toast', role: 'status' }, msg);
    doc.body.appendChild(t);
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.remove(), 2600);
  };

  /* ---------- countdown ring ---------- */
  ui.stopTimer = function () {
    ui.timers.forEach((id) => clearInterval(id));
    ui.timers = [];
  };
  ui.timerRing = function (seconds, onEnd) {
    const C = 2 * Math.PI * 34;
    const num = h('b', null, String(seconds));
    const ring = h('div', { class: 'ring', role: 'timer', 'aria-label': 'Countdown' },
      h('span', {
        html: '<svg viewBox="0 0 84 84"><defs><linearGradient id="ringGrad" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#7c5cff"/><stop offset="1" stop-color="#36a2ff"/></linearGradient></defs>' +
          '<circle class="bgc" cx="42" cy="42" r="34"/><circle class="fg" cx="42" cy="42" r="34" stroke-dasharray="' + C + '" stroke-dashoffset="0"/></svg>',
        style: { display: 'block', width: '100%', height: '100%' },
      }), num);
    const fg = ring.querySelector('.fg');
    const end = Date.now() + seconds * 1000;
    let last = seconds;
    const id = setInterval(function () {
      const left = Math.max(0, end - Date.now());
      const sec = Math.ceil(left / 1000);
      fg.style.strokeDashoffset = String(C * (1 - left / (seconds * 1000)));
      if (sec !== last) {
        last = sec;
        num.textContent = String(sec);
        if (sec <= 5 && sec > 0) { ring.classList.add('low'); UU.Sound.play('tick'); }
      }
      if (left <= 0) {
        clearInterval(id);
        ring.classList.add('up', 'low');
        num.textContent = '0';
        UU.Sound.play('alarm');
        if (onEnd) onEnd();
      }
    }, 200);
    ui.timers.push(id);
    return ring;
  };

  /* ---------- confetti ---------- */
  ui.stopConfetti = function () {
    if (ui._confetti) { cancelAnimationFrame(ui._confetti.raf); ui._confetti.canvas.remove(); ui._confetti = null; }
  };
  ui.confetti = function (colors) {
    if (!ui.S.animations) return;
    ui.stopConfetti();
    const canvas = h('canvas', { id: 'confetti', 'aria-hidden': 'true' });
    doc.body.appendChild(canvas);
    const dpr = Math.min(2, root.devicePixelRatio || 1);
    const W = (canvas.width = root.innerWidth * dpr);
    const H = (canvas.height = root.innerHeight * dpr);
    const g = canvas.getContext('2d');
    const rnd = (a, b) => a + Math.random() * (b - a);
    const parts = Array.from({ length: 150 }, () => ({
      x: rnd(0, W), y: rnd(-H * 0.6, 0), w: rnd(6, 12) * dpr, h: rnd(8, 16) * dpr,
      vy: rnd(2.2, 5.5) * dpr, vx: rnd(-1.6, 1.6) * dpr, r: rnd(0, 6.28), vr: rnd(-0.2, 0.2),
      c: colors[Math.floor(Math.random() * colors.length)],
    }));
    const t0 = Date.now();
    const state = { canvas, raf: 0 };
    ui._confetti = state;
    (function frame() {
      g.clearRect(0, 0, W, H);
      const age = Date.now() - t0;
      parts.forEach((p) => {
        p.x += p.vx; p.y += p.vy; p.r += p.vr;
        g.save(); g.translate(p.x, p.y); g.rotate(p.r); g.fillStyle = p.c; g.globalAlpha = Math.max(0, 1 - Math.max(0, age - 3000) / 1500);
        g.fillRect(-p.w / 2, -p.h / 2, p.w, p.h); g.restore();
      });
      if (age < 4500) state.raf = requestAnimationFrame(frame); else ui.stopConfetti();
    })();
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = UU;
})(typeof window !== 'undefined' ? window : globalThis);
