/* Original SVG artwork: logo, role emblems and UI icons. All inline, no external assets. */
(function (root) {
  'use strict';
  const UU = (root.UU = root.UU || {});

  const stroke = (inner) =>
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + inner + '</svg>';

  const UI = {
    back: stroke('<path d="M15 5l-7 7 7 7"/>'),
    home: stroke('<path d="M4 11l8-7 8 7"/><path d="M6 10v9h12v-9"/>'),
    play: '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M8 5.5v13a1 1 0 0 0 1.5.86l10.5-6.5a1 1 0 0 0 0-1.72L9.5 4.64A1 1 0 0 0 8 5.5z"/></svg>',
    sliders: stroke('<path d="M4 6h16M4 12h16M4 18h16"/><circle cx="9" cy="6" r="2.2" fill="currentColor"/><circle cx="15.5" cy="12" r="2.2" fill="currentColor"/><circle cx="8" cy="18" r="2.2" fill="currentColor"/>'),
    check: stroke('<path d="M5 12.5l4.5 4.5L19 7.5"/>'),
    close: stroke('<path d="M6 6l12 12M18 6L6 18"/>'),
    plus: stroke('<path d="M12 5v14M5 12h14"/>'),
    minus: stroke('<path d="M5 12h14"/>'),
    menu: stroke('<path d="M5 7h14M5 12h14M5 17h14"/>'),
    eye: stroke('<path d="M2 12s3.6-6.5 10-6.5S22 12 22 12s-3.6 6.5-10 6.5S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>'),
    eyeOff: stroke('<path d="M3 3l18 18"/><path d="M10.6 6.2A9.6 9.6 0 0 1 12 6c6.4 0 10 6 10 6a17 17 0 0 1-3.2 3.9M6.4 7.6A16.6 16.6 0 0 0 2 12s3.6 6 10 6c1.4 0 2.7-.3 3.8-.7"/>'),
    info: stroke('<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>'),
    users: stroke('<circle cx="9" cy="8" r="3.2"/><path d="M3 19c0-3.3 2.7-5.5 6-5.5s6 2.2 6 5.5"/><path d="M16 5.2a3.2 3.2 0 0 1 0 5.6M18 14c1.8.7 3 2.3 3 5"/>'),
    trophy: stroke('<path d="M8 4h8v5a4 4 0 0 1-8 0V4z"/><path d="M8 6H4.5c0 3 1.2 4.5 3.5 4.8M16 6h3.5c0 3-1.2 4.5-3.5 4.8"/><path d="M12 13v4M8.5 20h7M10 17h4"/>'),
    refresh: stroke('<path d="M20 11a8 8 0 0 0-14-4.5L4 9"/><path d="M4 4v5h5"/><path d="M4 13a8 8 0 0 0 14 4.5L20 15"/><path d="M20 20v-5h-5"/>'),
    lock: stroke('<rect x="5" y="11" width="14" height="9" rx="2.5"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>'),
    timer: stroke('<circle cx="12" cy="13" r="7.5"/><path d="M12 9v4l2.5 2M9.5 3h5"/>'),
    trash: stroke('<path d="M5 7h14M10 7V4.5h4V7M7 7l1 12.5h8L17 7"/>'),
    dice: stroke('<rect x="4" y="4" width="16" height="16" rx="4"/><circle cx="9" cy="9" r="1" fill="currentColor"/><circle cx="15" cy="15" r="1" fill="currentColor"/><circle cx="15" cy="9" r="1" fill="currentColor"/><circle cx="9" cy="15" r="1" fill="currentColor"/>'),
    chevron: stroke('<path d="M9 6l6 6-6 6"/>'),
  };

  /* Role emblems — 64x64, filled with currentColor */
  const ROLE_SVG = {
    civilian:
      '<svg viewBox="0 0 64 64" fill="currentColor" aria-hidden="true"><path d="M32 4l22 8v17c0 14-9 25-22 31C19 54 10 43 10 29V12z" opacity=".22"/><path d="M32 4l22 8v17c0 14-9 25-22 31C19 54 10 43 10 29V12z" fill="none" stroke="currentColor" stroke-width="3" stroke-linejoin="round"/><circle cx="32" cy="24" r="7.5"/><path d="M18.5 45c1.2-7.5 6.6-11.5 13.5-11.5S44.300 37.500 45.500 45c-3.800 4.200-8.500 6.800-13.500 9-5-2.200-9.700-4.800-13.500-9z"/></svg>',
    undercover:
      '<svg viewBox="0 0 64 64" fill="currentColor" aria-hidden="true"><ellipse cx="32" cy="29" rx="27" ry="6.500"/><path d="M17 28c0-13 5.500-19 15-19s15 6 15 19z"/><rect x="17" y="21" width="30" height="4.500" fill="var(--hat-band,#0a0d1f)" opacity=".55"/><path d="M9 38h46v3.500c0 7-5 11.500-11.500 11.500-6 0-7.500-4.500-11.500-4.500S26.500 53 20.500 53C14 53 9 48.500 9 41.500z"/><path d="M27 41h10" stroke="var(--hat-band,#0a0d1f)" stroke-width="2.500" stroke-linecap="round" opacity=".6"/></svg>',
    mrwhite:
      '<svg viewBox="0 0 64 64" fill="currentColor" aria-hidden="true"><path d="M10 56V31C10 16.600 19.800 6 32 6s22 10.600 22 25v25l-7.300-6-7.200 6-7.500-6-7.500 6-7.200-6z"/><circle cx="24" cy="30" r="4.500" fill="var(--ghost-eye,#0a0d1f)"/><circle cx="40" cy="30" r="4.500" fill="var(--ghost-eye,#0a0d1f)"/><path d="M26 41c3.500 3 8.500 3 12 0" fill="none" stroke="var(--ghost-eye,#0a0d1f)" stroke-width="3" stroke-linecap="round"/></svg>',
  };

  /* The logo: a masked face with one watching eye and one glowing "?" eye. */
  function logo(size) {
    const s = size || 120;
    return (
      '<svg viewBox="0 0 128 128" width="' + s + '" height="' + s + '" role="img" aria-label="Ultimate Undercover logo">' +
      '<defs>' +
      '<linearGradient id="uuG1" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#8b5cff"/><stop offset="1" stop-color="#2ea8ff"/></linearGradient>' +
      '<linearGradient id="uuG2" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#ff4fd8"/><stop offset="1" stop-color="#8b5cff"/></linearGradient>' +
      '<filter id="uuGlow" x="-30%" y="-30%" width="160%" height="160%"><feGaussianBlur stdDeviation="3" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>' +
      '</defs>' +
      '<rect x="6" y="6" width="116" height="116" rx="32" fill="url(#uuG1)"/>' +
      '<rect x="6" y="6" width="116" height="116" rx="32" fill="none" stroke="#fff" stroke-opacity=".25" stroke-width="2"/>' +
      '<path d="M20 52c15-9 30-11 44-5 14-6 29-4 44 5-1 21-10 35-26 35-9 0-14-6-18-12-4 6-9 12-18 12-16 0-25-14-26-35z" fill="#0b0e24"/>' +
      '<ellipse cx="45" cy="62" rx="12" ry="9" fill="#fff"/><circle cx="48" cy="62" r="5" fill="#0b0e24"/><circle cx="50" cy="60" r="1.800" fill="#fff"/>' +
      '<g filter="url(#uuGlow)"><ellipse cx="83" cy="62" rx="12" ry="9" fill="url(#uuG2)"/></g>' +
      '<text x="83" y="68" text-anchor="middle" font-family="system-ui,Segoe UI,Arial,sans-serif" font-weight="800" font-size="17" fill="#fff">?</text>' +
      '<path d="M44 100c12 6 28 6 40 0" fill="none" stroke="#fff" stroke-opacity=".85" stroke-width="4" stroke-linecap="round"/>' +
      '</svg>'
    );
  }

  UU.Icons = {
    ui: UI,
    role: ROLE_SVG,
    logo,
    html(svg, cls) { const s = document.createElement('span'); s.className = 'ico' + (cls ? ' ' + cls : ''); s.innerHTML = svg; return s; },
  };
})(typeof window !== 'undefined' ? window : globalThis);
