/* Copies only the files the app needs into ./www — the folder to hand to Capacitor / Android Studio. */
'use strict';
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const out = path.join(root, 'www');
fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(out, { recursive: true });
const items = ['index.html', 'manifest.webmanifest', 'sw.js', 'css', 'js', 'icons'];
function copy(src, dst) {
  const st = fs.statSync(src);
  if (st.isDirectory()) { fs.mkdirSync(dst, { recursive: true }); fs.readdirSync(src).forEach((f) => copy(path.join(src, f), path.join(dst, f))); }
  else fs.copyFileSync(src, dst);
}
items.forEach((i) => copy(path.join(root, i), path.join(out, i)));
let n = 0; (function count(d) { fs.readdirSync(d, { withFileTypes: true }).forEach((e) => (e.isDirectory() ? count(path.join(d, e.name)) : n++)); })(out);
console.log('www/ ready with ' + n + ' files');
