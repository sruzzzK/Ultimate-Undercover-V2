/* Renders the PNG app icons from the SVG artwork (needs Playwright + Chromium). */
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
(async () => {
  const browser = await chromium.launch();
  const jobs = [['icon.svg', 'icon-192.png', 192], ['icon.svg', 'icon-512.png', 512], ['icon-maskable.svg', 'icon-maskable-512.png', 512]];
  for (const [src, out, size] of jobs) {
    const svg = fs.readFileSync(path.join(__dirname, '..', 'icons', src), 'utf8');
    const page = await browser.newPage({ viewport: { width: size, height: size } });
    await page.setContent('<style>html,body{margin:0;background:transparent}svg{display:block;width:' + size + 'px;height:' + size + 'px}</style>' + svg);
    await page.screenshot({ path: path.join(__dirname, '..', 'icons', out), omitBackground: true });
    await page.close();
  }
  await browser.close();
  console.log('icons written');
})();
