# Ultimate Undercover

A social-deduction word party game for 3–20 players, played by passing one phone around.
Pure HTML + CSS + vanilla JavaScript — no dependencies, no build step, works offline.

- **21,373 distinct word pairs** · 35 categories · 4,353 unique words (real numbers, produced and checked by `tools/build-words.js`)
- Civilians · Undercover · Mr. White, private pass-the-device reveals, secret ballots, tie rules, timers
- Persistent word history so you rarely see the same pair twice
- Dark/light themes, animated background, synthesised sound effects, installable PWA

## Run it

```bash
npm start            # http://localhost:3000   (zero-dependency Node server)
# or just open index.html in a browser
```

## Project layout

```
index.html                 app shell
css/styles.css             all styling (dark + light themes)
js/data/words.js           GENERATED word database (data only, no logic)
js/util.js                 hashing, text normalisation, crypto RNG, safe storage
js/settings.js             persisted + validated settings
js/wordbank.js             filters, stats, fair picking, persistent history
js/engine.js               roles, rounds, voting, ties, Mr. White guess, win rules (pure logic)
js/sound.js                Web Audio sound effects (no audio files)
js/icons.js                original logo, role emblems, UI icons (inline SVG)
js/ui-*.js, js/app.js      screens (home, settings, setup, game, result) and boot
sw.js, manifest.webmanifest  offline support / installability
server.js                  static server for Railway
tools/source/words-*.txt   word source lists (edit these to add words)
tools/build-words.js       builds + validates js/data/words.js and prints the real count
tests/                     engine tests, browser end-to-end tests
```

## The word database

Source files list **clusters of sibling words** (e.g. *Tiger, Lion, Leopard, Cheetah…*). The builder expands each cluster into every unique pair, then:

- removes duplicates and reversed duplicates (A/B = B/A) across all categories
- drops pairs that are identical or where one word contains the other (*Ice* / *Ice Cube*)
- fails the build on malformed lines, empty words or duplicate words inside a cluster

Run `npm run build:words` after editing `tools/source/*.txt`. To add words, add a cluster line:
`m|My cluster name|Word one, Word two, Word three` (`e` / `m` / `h` = easy / medium / hard).

Honest notes on quality: pairs are generated from hand-written sibling groups, so they are related by construction, but individual pairs were not human-reviewed one by one. Difficulty is set per cluster (easy 3,823 · medium 16,333 · hard 1,217). A popular word can appear in many pairs (max 30); the picker avoids words seen in the last ~80 games to hide this.

### Replay system
- Every pair has a stable id (hash of the normalised pair). Used ids are stored in `localStorage`.
- Pairs are picked from the **unused** pool only; a category is chosen uniformly first, then a pair, preferring words not seen recently.
- When a selection is exhausted: either its history restarts automatically, or (setting off) the game asks you to reset / change filters.
- Settings → *Reset word history* clears everything.

## Rules implemented
- Civilians share one word; Undercovers get the related word; Mr. White gets none.
- **Classic reveal (default):** Civilians and Undercovers only see a word, so an Undercover doesn't know they are one. Mr. White always sees his role. Turn on *Tell players their role* in Settings to show roles.
- Roles: Auto, Manual, or Random (secret number of impostors). At least one Civilian, and impostors must start as a minority.
- Mr. White never speaks first; when voted out he gets one guess (case/spacing/plural tolerant, one typo allowed on long words). A correct guess wins instantly.
- **Impostor win rule (configurable):** Majority (impostors ≥ Civilians), Final two, or Final three.
- **Tie rule (configurable):** Re-vote (then random), Random, or No elimination (random after two stalemates in a row).
- Voting: secret ballots (counts shown only after everyone voted, never who voted for whom) or "group decides".
- Optional timers for descriptions and voting (visual + sound; they never auto-skip a player).
- "Check my word" lets a player privately re-read their word during discussion.
- Secrets are hidden automatically if the app goes to the background; refreshing mid-game offers *Resume* on the home screen.

## Deploy
**GitHub + Railway:** push this folder, create a Railway service from the repo. Railway runs `npm start` (`server.js`) and sets `PORT` automatically. Any static host also works (the app is plain files).

## Make an Android APK
1. `npm run build:www` → creates `www/` with only the runtime files.
2. **Capacitor (recommended):**
   ```bash
   npm i @capacitor/core @capacitor/cli @capacitor/android
   npx cap init "Ultimate Undercover" com.yourname.undercover --web-dir www
   npx cap add android && npx cap sync && npx cap open android
   ```
   Then build/sign the APK/AAB in Android Studio.
3. **Plain Android Studio WebView:** copy `www/` into `app/src/main/assets/` and load `file:///android_asset/index.html` with `settings.domStorageEnabled = true` (needed for saved settings/history). All scripts are classic scripts, so `file://` works; the service worker is simply skipped there.

## Tests
```bash
npm test            # 35 engine/word-bank tests incl. 3,000 simulated full games
npm run test:e2e    # needs Playwright + Chromium; 87 checks driving the real UI
```
