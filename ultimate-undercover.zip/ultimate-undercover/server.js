/* Zero-dependency static file server (used by Railway: `npm start`).
 * Serves this folder, gzips text assets once, and sets sensible cache headers. */
'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

const ROOT = __dirname;
const PORT = process.env.PORT || 3000;
const TYPES = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.txt': 'text/plain; charset=utf-8',
};
const PUBLIC = /^(index\.html|sw\.js|manifest\.webmanifest|css\/.+|js\/.+|icons\/.+)$/;
const cache = new Map();

function load(rel) {
  if (cache.has(rel)) return cache.get(rel);
  const file = path.join(ROOT, rel);
  if (!file.startsWith(ROOT) || !fs.existsSync(file) || !fs.statSync(file).isFile()) return null;
  const ext = path.extname(rel);
  const raw = fs.readFileSync(file);
  const entry = { type: TYPES[ext] || 'application/octet-stream', raw, gz: /\.(html|js|css|svg|webmanifest|json)$/.test(ext) ? zlib.gzipSync(raw, { level: 9 }) : null };
  cache.set(rel, entry);
  return entry;
}

http.createServer((req, res) => {
  let rel = decodeURIComponent(req.url.split('?')[0]).replace(/^\/+/, '') || 'index.html';
  if (rel.endsWith('/')) rel += 'index.html';
  const entry = PUBLIC.test(rel) ? load(rel) : null;
  if (!entry) { res.writeHead(404, { 'Content-Type': 'text/plain' }); return res.end('Not found'); }
  const headers = {
    'Content-Type': entry.type,
    'Cache-Control': rel === 'sw.js' || rel === 'index.html' ? 'no-cache' : 'public, max-age=3600',
    'X-Content-Type-Options': 'nosniff',
  };
  if (entry.gz && /\bgzip\b/.test(req.headers['accept-encoding'] || '')) {
    headers['Content-Encoding'] = 'gzip';
    res.writeHead(200, headers);
    return res.end(entry.gz);
  }
  res.writeHead(200, headers);
  res.end(entry.raw);
}).listen(PORT, () => console.log('Ultimate Undercover running on port ' + PORT));
